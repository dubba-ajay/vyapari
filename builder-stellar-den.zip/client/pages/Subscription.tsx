import React, { useState, useEffect } from "react";
import { Layout } from "@/components/Layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, Star, CreditCard, Shield, Zap } from "lucide-react";
import { useNavigate } from "react-router-dom";

declare global {
  interface Window {
    Razorpay: any;
  }
}

interface PlanFeature {
  text: string;
  included: boolean;
}

interface Plan {
  id: string;
  name: string;
  price: number;
  originalPrice?: number;
  period: string;
  popular?: boolean;
  features: PlanFeature[];
  description: string;
  stripePriceId?: string;
  razorpayPlanId?: string;
}

export default function Subscription() {
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState<string | null>(null);
  const [razorpayLoaded, setRazorpayLoaded] = useState(false);

  useEffect(() => {
    // Load Razorpay script
    const script = document.createElement("script");
    script.src = "https://checkout.razorpay.com/v1/checkout.js";
    script.async = true;
    script.onload = () => setRazorpayLoaded(true);
    document.body.appendChild(script);

    return () => {
      document.body.removeChild(script);
    };
  }, []);

  const plans: Plan[] = [
    {
      id: "starter",
      name: "Starter Plan",
      price: 1999,
      period: "month",
      description:
        "Ideal for solo creators or small teams starting digital promotion",
      features: [
        { text: "100 AI content generations/month", included: true },
        { text: "5 ad campaigns (Google/Facebook)", included: true },
        { text: "Basic analytics dashboard", included: true },
        { text: "WhatsApp & Email campaign (1,000 contacts)", included: true },
        { text: "Basic support", included: true },
        {
          text: "Ad spend not included - pay platforms directly",
          included: true,
        },
        { text: "Priority support", included: false },
        { text: "Custom branding options", included: false },
      ],
    },
    {
      id: "pro",
      name: "Pro Plan",
      price: 4999,
      period: "month",
      popular: true,
      description: "For growing businesses needing more automation & reach",
      features: [
        { text: "500 AI content generations/month", included: true },
        { text: "20 ad campaigns", included: true },
        { text: "Advanced analytics & performance tools", included: true },
        {
          text: "WhatsApp/SMS/Email campaigns (10,000 contacts)",
          included: true,
        },
        { text: "Priority support", included: true },
        { text: "Custom branding options", included: true },
        { text: "Performance-based add-ons available", included: true },
        {
          text: "Ad spend not included - pay platforms directly",
          included: true,
        },
      ],
    },
    {
      id: "agency",
      name: "Agency Plan",
      price: 9999,
      period: "month",
      description:
        "For agencies managing multiple clients or large-scale campaigns",
      features: [
        { text: "Unlimited AI generations", included: true },
        { text: "Up to 100 ad campaigns", included: true },
        { text: "Dedicated campaign manager", included: true },
        { text: "CRM + marketing automation suite", included: true },
        { text: "50,000+ outreach contacts", included: true },
        { text: "Dedicated onboarding + custom API access", included: true },
        { text: "SLA-backed priority support", included: true },
        { text: "Custom integrations available", included: true },
      ],
    },
  ];

  const handlePayment = async (plan: Plan, method: "stripe" | "razorpay") => {
    setIsLoading(true);
    setSelectedPlan(plan.id);

    try {
      if (method === "razorpay") {
        // Check if Razorpay is loaded
        if (!window.Razorpay || !razorpayLoaded) {
          alert("Payment system is loading. Please try again in a moment.");
          setIsLoading(false);
          setSelectedPlan(null);
          return;
        }

        // Get Razorpay key from environment or use test key
        const razorpayKey = import.meta.env.VITE_RAZORPAY_KEY_ID;
        if (!razorpayKey) {
          console.warn("Razorpay key not configured. Using test mode.");
        }

        // Razorpay integration for Indian customers
        const options = {
          key: razorpayKey || "rzp_test_key",
          amount: plan.price * 100, // Amount in paise
          currency: "INR",
          name: "Vyapari.AI",
          description: `${plan.name} Plan Subscription`,
          image: "/favicon.ico",
          order_id: `order_${Date.now()}`, // In production, get this from backend
          handler: function (response: any) {
            console.log("Payment successful:", response);
            // Handle successful payment
            navigate("/dashboard");
          },
          prefill: {
            name: "Customer Name",
            email: "customer@example.com",
            contact: "+91 9999999999",
          },
          notes: {
            plan: plan.id,
            period: plan.period,
          },
          theme: {
            color: "#f97316",
          },
          modal: {
            ondismiss: function () {
              setIsLoading(false);
              setSelectedPlan(null);
            },
          },
        };

        const rzp = new window.Razorpay(options);
        rzp.open();
      } else {
        // Stripe integration for international customers
        console.log("Stripe payment for plan:", plan.id);

        // For now, show demo message - in production, integrate with Stripe Checkout
        const proceedWithDemo = confirm(
          `This will start your ${plan.name} subscription for ₹${plan.price}/month.\n\n` +
            "Note: This is a demo. In production, you would be redirected to Stripe Checkout.\n\n" +
            "Click OK to proceed to dashboard (demo mode)",
        );

        if (proceedWithDemo) {
          alert("Demo: Payment successful! Redirecting to dashboard...");
          navigate("/dashboard");
        }
      }
    } catch (error) {
      console.error("Payment error:", error);

      // Better error messaging
      let errorMessage = "Payment failed. Please try again.";
      if (error instanceof Error) {
        if (error.message.includes("process")) {
          errorMessage = "Configuration error. Please contact support.";
        } else {
          errorMessage = `Payment error: ${error.message}`;
        }
      }

      alert(errorMessage);
    } finally {
      setIsLoading(false);
      setSelectedPlan(null);
    }
  };

  return (
    <Layout>
      <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Header */}
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold text-gray-900 mb-4">
              Choose Your Plan – Scale Your Growth With AI Power
            </h1>
            <p className="text-xl text-gray-600 max-w-4xl mx-auto">
              Whether you're a small business owner or a growing agency, our
              flexible plans give you full access to AI tools, campaign
              automation, and expert integrations — without any hidden fees.
            </p>
            <div className="mt-6 flex items-center justify-center space-x-4">
              <Badge className="bg-green-100 text-green-800">
                <Shield className="w-4 h-4 mr-1" />
                30-day money-back guarantee
              </Badge>
              <Badge className="bg-blue-100 text-blue-800">
                <Zap className="w-4 h-4 mr-1" />
                Setup in 5 minutes
              </Badge>
            </div>
          </div>

          {/* Pricing Plans */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
            {plans.map((plan) => {
              const getCardClasses = () => {
                if (plan.id === "starter")
                  return "border-2 border-green-500 shadow-lg";
                if (plan.id === "pro")
                  return "border-2 border-blue-500 shadow-xl scale-105";
                if (plan.id === "agency")
                  return "border-2 border-purple-500 shadow-lg";
                return "border border-gray-200";
              };

              return (
                <Card
                  key={plan.id}
                  className={`relative ${getCardClasses()} transition-all duration-300 hover:shadow-xl`}
                >
                  {plan.popular && (
                    <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                      <Badge className="bg-blue-500 text-white px-4 py-1">
                        <Star className="w-4 h-4 mr-1" />
                        Most Popular
                      </Badge>
                    </div>
                  )}
                  {plan.id === "starter" && (
                    <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                      <Badge className="bg-green-500 text-white px-4 py-1">
                        🟢 Great Start
                      </Badge>
                    </div>
                  )}
                  {plan.id === "agency" && (
                    <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                      <Badge className="bg-purple-500 text-white px-4 py-1">
                        🟣 Enterprise
                      </Badge>
                    </div>
                  )}

                  <CardHeader className="text-center pb-4">
                    <CardTitle className="text-2xl font-bold">
                      {plan.name}
                    </CardTitle>
                    <div className="mt-4">
                      <div className="flex items-center justify-center">
                        <span className="text-3xl font-bold">
                          ₹{plan.price.toLocaleString()}
                        </span>
                        <span className="text-gray-500 ml-2">
                          /{plan.period}
                        </span>
                      </div>
                      {plan.originalPrice && (
                        <div className="text-sm text-gray-500 mt-1">
                          <span className="line-through">
                            ₹{plan.originalPrice.toLocaleString()}
                          </span>
                          <span className="text-green-600 ml-2 font-semibold">
                            Save{" "}
                            {Math.round(
                              ((plan.originalPrice - plan.price) /
                                plan.originalPrice) *
                                100,
                            )}
                            %
                          </span>
                        </div>
                      )}
                    </div>
                    <p className="text-gray-600 text-sm mt-3">
                      {plan.description}
                    </p>
                  </CardHeader>

                  <CardContent className="space-y-6">
                    <ul className="space-y-3">
                      {plan.features.map((feature, index) => (
                        <li key={index} className="flex items-start">
                          <CheckCircle
                            className={`w-5 h-5 mt-0.5 mr-3 ${
                              feature.included
                                ? "text-green-500"
                                : "text-gray-300"
                            }`}
                          />
                          <span
                            className={
                              feature.included
                                ? "text-gray-900"
                                : "text-gray-400 line-through"
                            }
                          >
                            {feature.text}
                          </span>
                        </li>
                      ))}
                    </ul>

                    <div className="space-y-3 pt-6 border-t">
                      <Button
                        className={`w-full ${
                          plan.id === "starter"
                            ? "bg-green-600 hover:bg-green-700"
                            : plan.id === "pro"
                              ? "bg-blue-600 hover:bg-blue-700"
                              : plan.id === "agency"
                                ? "bg-purple-600 hover:bg-purple-700"
                                : "bg-gray-900 hover:bg-gray-800"
                        }`}
                        size="lg"
                        onClick={() => handlePayment(plan, "razorpay")}
                        disabled={isLoading && selectedPlan === plan.id}
                      >
                        <CreditCard className="w-4 h-4 mr-2" />
                        {isLoading && selectedPlan === plan.id
                          ? "Processing..."
                          : `Pay with Razorpay (INR)`}
                      </Button>

                      <Button
                        variant="outline"
                        className="w-full"
                        onClick={() => handlePayment(plan, "stripe")}
                        disabled={isLoading}
                      >
                        Pay with Stripe (USD)
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          {/* Important Note */}
          <Card className="mb-12 border-orange-200 bg-orange-50">
            <CardHeader>
              <CardTitle className="text-center flex items-center justify-center text-orange-800">
                <Shield className="w-6 h-6 mr-2" />
                Important Note About Ad Spend
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center">
                <p className="text-orange-700 text-lg font-medium mb-4">
                  All ad campaigns (Google, Facebook, Instagram) require users
                  to pay the ad budget directly to those platforms.
                </p>
                <p className="text-orange-600">
                  We only manage and optimize the campaigns. Your ad spend goes
                  directly to Google, Facebook, etc.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Add-Ons Section */}
          <Card className="mb-12">
            <CardHeader>
              <CardTitle className="text-center">Optional Add-Ons</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div className="flex justify-between items-center p-4 bg-gray-50 rounded-lg">
                    <span className="font-medium">Additional Ad Campaigns</span>
                    <span className="text-brand-orange-600 font-bold">
                      ₹250/campaign
                    </span>
                  </div>
                  <div className="flex justify-between items-center p-4 bg-gray-50 rounded-lg">
                    <span className="font-medium">Extra AI Usage</span>
                    <span className="text-brand-orange-600 font-bold">
                      ₹1 per generation
                    </span>
                  </div>
                </div>
                <div className="space-y-4">
                  <div className="flex justify-between items-center p-4 bg-gray-50 rounded-lg">
                    <span className="font-medium">API Overages</span>
                    <span className="text-brand-orange-600 font-bold">
                      Pay-as-you-go
                    </span>
                  </div>
                  <div className="flex justify-between items-center p-4 bg-gray-50 rounded-lg">
                    <span className="font-medium">One-Time Setup</span>
                    <span className="text-brand-orange-600 font-bold">
                      ₹2,000 - ₹10,000
                    </span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Features Comparison */}
          <Card className="mb-12">
            <CardHeader>
              <CardTitle className="text-center">
                Why Choose Vyapari.AI?
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div className="text-center">
                  <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Zap className="w-8 h-8 text-blue-600" />
                  </div>
                  <h3 className="text-lg font-semibold mb-2">
                    AI-Powered Content
                  </h3>
                  <p className="text-gray-600">
                    Generate professional marketing content in seconds with our
                    advanced AI
                  </p>
                </div>
                <div className="text-center">
                  <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Shield className="w-8 h-8 text-green-600" />
                  </div>
                  <h3 className="text-lg font-semibold mb-2">
                    Secure & Reliable
                  </h3>
                  <p className="text-gray-600">
                    Enterprise-grade security with 99.9% uptime guarantee
                  </p>
                </div>
                <div className="text-center">
                  <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Star className="w-8 h-8 text-orange-600" />
                  </div>
                  <h3 className="text-lg font-semibold mb-2">
                    Indian Market Focus
                  </h3>
                  <p className="text-gray-600">
                    Built specifically for Indian businesses with local festival
                    campaigns
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* FAQ Section */}
          <Card>
            <CardHeader>
              <CardTitle className="text-center">
                Frequently Asked Questions
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div>
                  <h4 className="font-semibold mb-2">
                    Can I change my plan anytime?
                  </h4>
                  <p className="text-gray-600 text-sm">
                    Yes, you can upgrade or downgrade your plan at any time.
                    Changes will be reflected in your next billing cycle.
                  </p>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Is there a free trial?</h4>
                  <p className="text-gray-600 text-sm">
                    Yes, all plans come with a 7-day free trial. No credit card
                    required to start.
                  </p>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">
                    Do I need to pay for ad spend separately?
                  </h4>
                  <p className="text-gray-600 text-sm">
                    Yes, all ad budgets (Google, Facebook, Instagram) are paid
                    directly to those platforms. We only manage and optimize
                    your campaigns.
                  </p>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">
                    What about add-ons and extra usage?
                  </h4>
                  <p className="text-gray-600 text-sm">
                    You can purchase additional campaigns (₹250 each), extra AI
                    generations (₹1 each), and API overages on a pay-as-you-go
                    basis.
                  </p>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">
                    What payment methods do you accept?
                  </h4>
                  <p className="text-gray-600 text-sm">
                    We accept all major credit cards, UPI, net banking, and
                    digital wallets through Razorpay and Stripe.
                  </p>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Do you offer refunds?</h4>
                  <p className="text-gray-600 text-sm">
                    Yes, we offer a 30-day money-back guarantee. If you're not
                    satisfied, we'll refund your money.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </Layout>
  );
}

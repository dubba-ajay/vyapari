import React, { useState, useCallback, useMemo } from "react";
import { DashboardLayout } from "@/components/DashboardLayout";
import { useLanguage } from "@/hooks/useLanguage";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import { Switch } from "@/components/ui/switch";
import { Slider } from "@/components/ui/slider";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Megaphone,
  Eye,
  Target,
  IndianRupee,
  Upload,
  Image as ImageIcon,
  Sparkles,
  Search,
  TrendingUp,
  Download,
  Share2,
  Zap,
  Globe,
  BarChart3,
  Clock,
  Copy,
  Play,
  Pause,
  Video,
  Camera,
  Edit3,
  Trash2,
  Heart,
  ThumbsUp,
  MessageSquare,
  ExternalLink,
  MapPin,
  Users,
  Calendar,
  Smartphone,
  Monitor,
  Tablet,
  CheckCircle,
  AlertCircle,
  XCircle,
  RefreshCw,
  Settings,
  PlusCircle,
  Plus,
  X,
  ArrowRight,
  MousePointer,
  CreditCard,
  DollarSign,
  Layers,
  Filter,
  Tag,
  Building,
  Phone,
  Mail,
  Star,
  Award,
  ShoppingCart,
  Lightbulb,
  PieChart,
  LineChart,
  TrendingDown,
  Facebook,
  Chrome,
  Instagram,
  Youtube,
} from "lucide-react";
import {
  getContentTemplate,
  formatContent,
  getCTA,
  getHashtags,
} from "@/lib/regionalLanguage";

const adPlatforms = [
  {
    id: "google-search",
    name: "Google Search",
    icon: Search,
    description: "Text ads in search results",
    color: "bg-blue-600",
    avgCPC: "₹0",
    avgCTR: "0%",
    reachPotential: "0",
  },
  {
    id: "google-display",
    name: "Google Display",
    icon: Monitor,
    description: "Visual banner ads across websites",
    color: "bg-green-600",
    avgCPC: "₹0",
    avgCTR: "0%",
    reachPotential: "0",
  },
  {
    id: "facebook",
    name: "Facebook Ads",
    icon: Facebook,
    description: "Social media advertising",
    color: "bg-blue-700",
    avgCPC: "₹0",
    avgCTR: "0%",
    reachPotential: "0",
  },
  {
    id: "instagram",
    name: "Instagram Ads",
    icon: Instagram,
    description: "Visual storytelling ads",
    color: "bg-pink-600",
    avgCPC: "₹0",
    avgCTR: "0%",
    reachPotential: "0",
  },
  {
    id: "youtube",
    name: "YouTube Ads",
    icon: Youtube,
    description: "Video advertising platform",
    color: "bg-red-600",
    avgCPC: "₹0",
    avgCTR: "0%",
    reachPotential: "0",
  },
];

const adObjectives = [
  {
    id: "brand_awareness",
    name: "Brand Awareness",
    description: "Increase visibility and recognition",
    icon: Eye,
    bestFor: ["New businesses", "Product launches"],
  },
  {
    id: "reach",
    name: "Reach",
    description: "Show ads to maximum people",
    icon: Users,
    bestFor: ["Local businesses", "Event promotion"],
  },
  {
    id: "traffic",
    name: "Website Traffic",
    description: "Drive visitors to your website",
    icon: ExternalLink,
    bestFor: ["E-commerce", "Content sites"],
  },
  {
    id: "engagement",
    name: "Engagement",
    description: "Get likes, comments, and shares",
    icon: Heart,
    bestFor: ["Social presence", "Community building"],
  },
  {
    id: "app_installs",
    name: "App Installs",
    description: "Promote mobile app downloads",
    icon: Smartphone,
    bestFor: ["Mobile apps", "Games"],
  },
  {
    id: "lead_generation",
    name: "Lead Generation",
    description: "Collect customer information",
    icon: Target,
    bestFor: ["B2B services", "Consultancy"],
  },
  {
    id: "conversions",
    name: "Conversions",
    description: "Drive sales and purchases",
    icon: ShoppingCart,
    bestFor: ["Online stores", "Service bookings"],
  },
];

const targetingOptions = [
  { id: "demographics", name: "Demographics", icon: Users },
  { id: "interests", name: "Interests", icon: Heart },
  { id: "behaviors", name: "Behaviors", icon: TrendingUp },
  { id: "location", name: "Location", icon: MapPin },
  { id: "custom_audiences", name: "Custom Audiences", icon: Target },
  { id: "lookalike", name: "Lookalike Audiences", icon: Copy },
];

interface AdCampaign {
  id: number;
  name: string;
  platform: string;
  objective: string;
  status: "active" | "paused" | "completed" | "draft";
  budget: number;
  spent: number;
  impressions: number;
  clicks: number;
  conversions: number;
  ctr: number;
  cpc: number;
  language: string;
  createdAt: string;
  mediaUrls: string[];
  adCopy: {
    headline: string;
    description: string;
    cta: string;
  };
}

const mockCampaigns: AdCampaign[] = [];

export default function Ads() {
  const { currentLanguage, selectedMarketTier } = useLanguage();
  const [selectedPlatform, setSelectedPlatform] = useState("facebook");
  const [adObjective, setAdObjective] = useState("conversions");
  const [businessName, setBusinessName] = useState("");
  const [productService, setProductService] = useState("");
  const [specialOffer, setSpecialOffer] = useState("");
  const [dailyBudget, setDailyBudget] = useState(500);
  const [totalBudget, setTotalBudget] = useState(5000);
  const [campaignDuration, setCampaignDuration] = useState(7);
  const [targetAudience, setTargetAudience] = useState({
    ageMin: 18,
    ageMax: 65,
    gender: "all",
    interests: [] as string[],
    locations: [] as string[],
    languages: [currentLanguage.code],
  });
  const [adCreatives, setAdCreatives] = useState<
    Array<{
      id: string;
      type: "image" | "video" | "carousel";
      mediaUrls: string[];
      headline: string;
      description: string;
      cta: string;
      performance?: {
        ctr: number;
        cpc: number;
        conversions: number;
      };
    }>
  >([]);
  const [isGeneratingAd, setIsGeneratingAd] = useState(false);
  const [campaigns, setCampaigns] = useState<AdCampaign[]>(mockCampaigns);
  const [selectedCampaign, setSelectedCampaign] = useState<AdCampaign | null>(
    null,
  );
  const [adPreviewDevice, setAdPreviewDevice] = useState<"mobile" | "desktop">(
    "mobile",
  );

  // Advanced Media Management
  const [uploadedAssets, setUploadedAssets] = useState<
    Array<{
      id: string;
      type: "image" | "video";
      url: string;
      name: string;
      size: number;
      dimensions?: { width: number; height: number };
      duration?: number;
    }>
  >([]);
  const [isUploadingAssets, setIsUploadingAssets] = useState(false);
  const [assetLibraryOpen, setAssetLibraryOpen] = useState(false);

  // AI-Powered Ad Generation
  const generateAdCampaign = useCallback(async () => {
    if (!selectedPlatform || !businessName || !productService) return;

    setIsGeneratingAd(true);

    // Simulate AI processing
    await new Promise((resolve) => setTimeout(resolve, 3000));

    try {
      const template = getContentTemplate(
        "social_post",
        currentLanguage.code,
        "promotional",
      );
      const hashtags = getHashtags(currentLanguage.code);
      const cta = getCTA(currentLanguage.code, "contact");

      const variables = {
        businessName: businessName || "Your Business",
        productService: productService,
        specialOffer: specialOffer,
      };

      const baseContent = formatContent(template, variables);

      // Platform-specific ad creative generation
      const newCreatives = [];

      if (selectedPlatform === "google-search") {
        newCreatives.push({
          id: `creative_${Date.now()}`,
          type: "image" as const,
          mediaUrls: [],
          headline: `${businessName} - ${specialOffer || "Professional Services"}`,
          description:
            baseContent.split("\n")[0] || `Expert ${productService} services`,
          cta: cta || "Learn More",
        });
      } else {
        // Social platform creatives
        newCreatives.push({
          id: `creative_${Date.now()}`,
          type: "image" as const,
          mediaUrls: uploadedAssets.slice(0, 1).map((asset) => asset.url),
          headline: `${specialOffer || "Transform Your Business"}`,
          description: baseContent,
          cta: cta || "Shop Now",
        });

        if (uploadedAssets.length > 1) {
          newCreatives.push({
            id: `creative_${Date.now() + 1}`,
            type: "carousel" as const,
            mediaUrls: uploadedAssets.slice(0, 5).map((asset) => asset.url),
            headline: `Discover ${businessName}`,
            description: `Multiple options for ${productService}`,
            cta: "View Collection",
          });
        }
      }

      setAdCreatives(newCreatives);
    } catch (error) {
      console.error("Error generating ad:", error);
    }

    setIsGeneratingAd(false);
  }, [
    selectedPlatform,
    businessName,
    productService,
    specialOffer,
    currentLanguage.code,
    uploadedAssets,
  ]);

  // Media Upload Handler
  const handleAssetUpload = useCallback(async (files: FileList) => {
    setIsUploadingAssets(true);

    const newAssets = Array.from(files).map((file, index) => {
      const id = `asset_${Date.now()}_${index}`;
      const url = URL.createObjectURL(file);

      return {
        id,
        type: file.type.startsWith("video/")
          ? ("video" as const)
          : ("image" as const),
        url,
        name: file.name,
        size: file.size,
        dimensions: { width: 1080, height: 1080 }, // Mock dimensions
        duration: file.type.startsWith("video/") ? 30 : undefined,
      };
    });

    // Simulate upload processing
    await new Promise((resolve) => setTimeout(resolve, 2000));

    setUploadedAssets((prev) => [...prev, ...newAssets]);
    setIsUploadingAssets(false);
  }, []);

  const removeAsset = useCallback((assetId: string) => {
    setUploadedAssets((prev) => prev.filter((a) => a.id !== assetId));
  }, []);

  const launchCampaign = useCallback(() => {
    if (adCreatives.length === 0) return;

    const newCampaign: AdCampaign = {
      id: Date.now(),
      name: `${businessName} Campaign - ${new Date().toLocaleDateString()}`,
      platform: selectedPlatform,
      objective: adObjective,
      status: "active",
      budget: totalBudget,
      spent: 0,
      impressions: 0,
      clicks: 0,
      conversions: 0,
      ctr: 0,
      cpc: 0,
      language: currentLanguage.code,
      createdAt: new Date().toISOString().split("T")[0],
      mediaUrls: adCreatives[0]?.mediaUrls || [],
      adCopy: {
        headline: adCreatives[0]?.headline || "",
        description: adCreatives[0]?.description || "",
        cta: adCreatives[0]?.cta || "",
      },
    };

    setCampaigns((prev) => [newCampaign, ...prev]);

    alert(
      `Campaign launched successfully on ${adPlatforms.find((p) => p.id === selectedPlatform)?.name}! 🚀`,
    );

    // Reset form
    setAdCreatives([]);
    setSpecialOffer("");
    setProductService("");
  }, [
    adCreatives,
    businessName,
    selectedPlatform,
    adObjective,
    totalBudget,
    currentLanguage.code,
  ]);

  const duplicateCampaign = useCallback(
    (campaignId: number) => {
      const campaign = campaigns.find((c) => c.id === campaignId);
      if (campaign) {
        const newCampaign = {
          ...campaign,
          id: Date.now(),
          name: `${campaign.name} (Copy)`,
          status: "draft" as const,
          spent: 0,
          impressions: 0,
          clicks: 0,
          conversions: 0,
        };
        setCampaigns((prev) => [newCampaign, ...prev]);
      }
    },
    [campaigns],
  );

  const selectedPlatformData = useMemo(() => {
    return adPlatforms.find((p) => p.id === selectedPlatform);
  }, [selectedPlatform]);

  const selectedObjectiveData = useMemo(() => {
    return adObjectives.find((o) => o.id === adObjective);
  }, [adObjective]);

  const estimatedMetrics = useMemo(() => {
    const platform = selectedPlatformData;
    if (!platform) return null;

    const estimatedImpressions = dailyBudget * campaignDuration * 150;
    const estimatedClicks = Math.round(
      estimatedImpressions * (parseFloat(platform.avgCTR) / 100),
    );
    const estimatedConversions = Math.round(estimatedClicks * 0.05);

    return {
      impressions: estimatedImpressions,
      clicks: estimatedClicks,
      conversions: estimatedConversions,
      reach: Math.round(estimatedImpressions * 0.7),
    };
  }, [dailyBudget, campaignDuration, selectedPlatformData]);

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Enhanced Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight bg-gradient-to-r from-blue-600 via-purple-600 to-red-600 bg-clip-text text-transparent">
              Google & Facebook Ads Manager
            </h1>
            <p className="text-muted-foreground">
              Create high-performing ad campaigns with AI-powered optimization
              for {selectedMarketTier.name}
            </p>
          </div>
          <div className="flex items-center gap-3">
            <Badge variant="outline" className="gap-2">
              <Globe className="h-4 w-4" />
              {selectedMarketTier.name}
            </Badge>
            <Badge className="bg-gradient-to-r from-blue-500 to-purple-500 text-white gap-2">
              <Sparkles className="w-4 h-4" />
              AI-Powered Ads
            </Badge>
            <Badge variant="secondary" className="gap-2">
              <TrendingUp className="w-4 h-4" />
              {campaigns.filter((c) => c.status === "active").length} Active
            </Badge>
          </div>
        </div>

        {/* Platform Overview */}
        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4">
          {adPlatforms.map((platform) => {
            const IconComponent = platform.icon;
            const isSelected = selectedPlatform === platform.id;

            return (
              <Card
                key={platform.id}
                className={`cursor-pointer transition-all duration-200 hover:scale-105 hover:shadow-lg ${
                  isSelected ? "ring-2 ring-primary shadow-lg" : ""
                }`}
                onClick={() => setSelectedPlatform(platform.id)}
              >
                <CardContent className="p-4">
                  <div className="flex items-center gap-3 mb-3">
                    <div
                      className={`p-3 rounded-lg ${platform.color} text-white`}
                    >
                      <IconComponent className="h-5 w-5" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-sm">{platform.name}</p>
                      <p className="text-xs text-muted-foreground">
                        {platform.description}
                      </p>
                    </div>
                  </div>

                  <div className="space-y-2 text-xs">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Avg CPC:</span>
                      <span className="font-medium">{platform.avgCPC}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Avg CTR:</span>
                      <span className="font-medium">{platform.avgCTR}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Reach:</span>
                      <span className="font-medium">
                        {platform.reachPotential}
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        <Tabs defaultValue="create" className="space-y-6">
          <TabsList className="grid w-full grid-cols-6">
            <TabsTrigger value="create">Create Campaign</TabsTrigger>
            <TabsTrigger value="assets">Media Assets</TabsTrigger>
            <TabsTrigger value="campaigns">Active Campaigns</TabsTrigger>
            <TabsTrigger value="analytics">Performance</TabsTrigger>
            <TabsTrigger value="audiences">Audiences</TabsTrigger>
            <TabsTrigger value="insights">Market Insights</TabsTrigger>
          </TabsList>

          <TabsContent value="create">
            <div className="grid grid-cols-1 lg:grid-cols-7 gap-6">
              {/* Campaign Builder */}
              <div className="lg:col-span-4 space-y-6">
                {/* Campaign Objective */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Target className="h-5 w-5 text-blue-500" />
                      Campaign Objective
                    </CardTitle>
                    <CardDescription>
                      Choose what you want to achieve with your advertising
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 lg:grid-cols-3 gap-3">
                      {adObjectives.map((objective) => {
                        const IconComponent = objective.icon;
                        const isSelected = adObjective === objective.id;

                        return (
                          <Card
                            key={objective.id}
                            className={`cursor-pointer transition-all ${
                              isSelected
                                ? "ring-2 ring-primary bg-primary/5"
                                : "hover:shadow-md"
                            }`}
                            onClick={() => setAdObjective(objective.id)}
                          >
                            <CardContent className="p-4">
                              <div className="flex items-start gap-3">
                                <IconComponent className="h-5 w-5 text-primary mt-1" />
                                <div>
                                  <p className="font-medium text-sm">
                                    {objective.name}
                                  </p>
                                  <p className="text-xs text-muted-foreground mb-2">
                                    {objective.description}
                                  </p>
                                  <div className="text-xs text-muted-foreground">
                                    <p className="font-medium">Best for:</p>
                                    {objective.bestFor.map((item, idx) => (
                                      <p key={idx}>• {item}</p>
                                    ))}
                                  </div>
                                </div>
                              </div>
                            </CardContent>
                          </Card>
                        );
                      })}
                    </div>
                  </CardContent>
                </Card>

                {/* Business Information */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Building className="h-5 w-5 text-green-500" />
                      Business Information
                    </CardTitle>
                    <CardDescription>
                      Tell us about your business to create targeted ads
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="business-name">Business Name</Label>
                        <Input
                          id="business-name"
                          placeholder="Enter your business name"
                          value={businessName}
                          onChange={(e) => setBusinessName(e.target.value)}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="product-service">Product/Service</Label>
                        <Input
                          id="product-service"
                          placeholder={
                            currentLanguage.code === "hi"
                              ? "जैसे: हेयर सैलून, रेस्टोरेंट"
                              : "e.g., Hair Salon, Restaurant"
                          }
                          value={productService}
                          onChange={(e) => setProductService(e.target.value)}
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="special-offer">
                        Special Offer (Optional)
                      </Label>
                      <Input
                        id="special-offer"
                        placeholder={
                          currentLanguage.code === "hi"
                            ? "जैसे: 30% छूट, खरीदो 1 पाओ 1 फ्री"
                            : "e.g., 30% Off, Buy 1 Get 1 Free"
                        }
                        value={specialOffer}
                        onChange={(e) => setSpecialOffer(e.target.value)}
                      />
                    </div>
                  </CardContent>
                </Card>

                {/* Budget & Duration */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <IndianRupee className="h-5 w-5 text-orange-500" />
                      Budget & Schedule
                    </CardTitle>
                    <CardDescription>
                      Set your advertising budget and campaign duration
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-3">
                        <Label>Daily Budget: ₹{dailyBudget}</Label>
                        <Slider
                          value={[dailyBudget]}
                          onValueChange={(value) => setDailyBudget(value[0])}
                          max={2000}
                          min={100}
                          step={50}
                          className="w-full"
                        />
                        <div className="flex justify-between text-xs text-muted-foreground">
                          <span>₹100</span>
                          <span>₹2,000</span>
                        </div>
                      </div>

                      <div className="space-y-3">
                        <Label>
                          Campaign Duration: {campaignDuration} days
                        </Label>
                        <Slider
                          value={[campaignDuration]}
                          onValueChange={(value) => {
                            setCampaignDuration(value[0]);
                            setTotalBudget(dailyBudget * value[0]);
                          }}
                          max={30}
                          min={1}
                          step={1}
                          className="w-full"
                        />
                        <div className="flex justify-between text-xs text-muted-foreground">
                          <span>1 day</span>
                          <span>30 days</span>
                        </div>
                      </div>
                    </div>

                    <div className="p-4 bg-blue-50 rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-medium">
                          Total Campaign Budget
                        </span>
                        <span className="text-2xl font-bold text-blue-600">
                          ₹{totalBudget.toLocaleString()}
                        </span>
                      </div>

                      {estimatedMetrics && (
                        <div className="grid grid-cols-2 gap-4 mt-4 text-sm">
                          <div className="text-center p-2 bg-white rounded">
                            <p className="font-semibold">
                              {estimatedMetrics.impressions.toLocaleString()}
                            </p>
                            <p className="text-muted-foreground">
                              Est. Impressions
                            </p>
                          </div>
                          <div className="text-center p-2 bg-white rounded">
                            <p className="font-semibold">
                              {estimatedMetrics.clicks.toLocaleString()}
                            </p>
                            <p className="text-muted-foreground">Est. Clicks</p>
                          </div>
                          <div className="text-center p-2 bg-white rounded">
                            <p className="font-semibold">
                              {estimatedMetrics.reach.toLocaleString()}
                            </p>
                            <p className="text-muted-foreground">Est. Reach</p>
                          </div>
                          <div className="text-center p-2 bg-white rounded">
                            <p className="font-semibold">
                              {estimatedMetrics.conversions}
                            </p>
                            <p className="text-muted-foreground">
                              Est. Conversions
                            </p>
                          </div>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>

                {/* AI Ad Generation */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Sparkles className="h-5 w-5 text-purple-500" />
                      AI Ad Creator
                    </CardTitle>
                    <CardDescription>
                      Generate optimized ad creatives using artificial
                      intelligence
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex gap-3">
                      <Button
                        onClick={generateAdCampaign}
                        disabled={
                          isGeneratingAd || !businessName || !productService
                        }
                        className="flex-1 bg-gradient-to-r from-purple-500 to-pink-500 hover:opacity-90"
                        size="lg"
                      >
                        {isGeneratingAd ? (
                          <>
                            <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                            Generating Ads...
                          </>
                        ) : (
                          <>
                            <Sparkles className="mr-2 h-4 w-4" />
                            Generate AI Ad Campaign
                          </>
                        )}
                      </Button>
                      <Button variant="outline" size="lg">
                        <Settings className="h-4 w-4" />
                      </Button>
                    </div>

                    {/* Generated Ad Creatives */}
                    {adCreatives.length > 0 && (
                      <div className="space-y-4">
                        <Separator />
                        <div className="flex items-center justify-between">
                          <h4 className="font-semibold">
                            Generated Ad Creatives
                          </h4>
                          <Badge variant="secondary">
                            {adCreatives.length} variants
                          </Badge>
                        </div>

                        <div className="grid gap-4">
                          {adCreatives.map((creative, index) => (
                            <Card
                              key={creative.id}
                              className="border-2 border-purple-200"
                            >
                              <CardContent className="p-4">
                                <div className="flex items-start justify-between mb-3">
                                  <div className="flex items-center gap-2">
                                    <Badge variant="outline">
                                      Creative {index + 1}
                                    </Badge>
                                    <Badge variant="secondary">
                                      {creative.type}
                                    </Badge>
                                  </div>
                                  <div className="flex gap-2">
                                    <Button variant="outline" size="sm">
                                      <Edit3 className="h-3 w-3" />
                                    </Button>
                                    <Button variant="outline" size="sm">
                                      <Copy className="h-3 w-3" />
                                    </Button>
                                  </div>
                                </div>

                                <div className="space-y-2">
                                  <div>
                                    <span className="text-sm font-medium">
                                      Headline:{" "}
                                    </span>
                                    <span className="text-sm">
                                      {creative.headline}
                                    </span>
                                  </div>
                                  <div>
                                    <span className="text-sm font-medium">
                                      Description:{" "}
                                    </span>
                                    <span className="text-sm">
                                      {creative.description}
                                    </span>
                                  </div>
                                  <div>
                                    <span className="text-sm font-medium">
                                      CTA:{" "}
                                    </span>
                                    <span className="text-sm">
                                      {creative.cta}
                                    </span>
                                  </div>
                                  {creative.mediaUrls.length > 0 && (
                                    <div className="flex gap-2 mt-2">
                                      {creative.mediaUrls
                                        .slice(0, 3)
                                        .map((url, idx) => (
                                          <img
                                            key={idx}
                                            src={url}
                                            alt={`Creative ${index + 1} media ${idx + 1}`}
                                            className="w-16 h-16 object-cover rounded border"
                                          />
                                        ))}
                                      {creative.mediaUrls.length > 3 && (
                                        <div className="w-16 h-16 bg-muted rounded border flex items-center justify-center text-xs">
                                          +{creative.mediaUrls.length - 3}
                                        </div>
                                      )}
                                    </div>
                                  )}
                                </div>
                              </CardContent>
                            </Card>
                          ))}
                        </div>

                        <Button
                          onClick={launchCampaign}
                          className="w-full"
                          size="lg"
                        >
                          <TrendingUp className="mr-2 h-4 w-4" />
                          Launch Campaign with {adCreatives.length} Creative
                          {adCreatives.length > 1 ? "s" : ""}
                        </Button>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>

              {/* Ad Preview & Insights */}
              <div className="lg:col-span-3 space-y-6">
                {/* Platform Preview */}
                <Card>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg">Ad Preview</CardTitle>
                      <div className="flex items-center gap-2">
                        <Button
                          variant={
                            adPreviewDevice === "mobile" ? "default" : "outline"
                          }
                          size="sm"
                          onClick={() => setAdPreviewDevice("mobile")}
                        >
                          <Smartphone className="h-4 w-4" />
                        </Button>
                        <Button
                          variant={
                            adPreviewDevice === "desktop"
                              ? "default"
                              : "outline"
                          }
                          size="sm"
                          onClick={() => setAdPreviewDevice("desktop")}
                        >
                          <Monitor className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                    <CardDescription>
                      Preview how your ad will appear on{" "}
                      {selectedPlatformData?.name}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div
                      className={`mx-auto transition-all duration-300 ${
                        adPreviewDevice === "mobile" ? "max-w-sm" : "max-w-full"
                      }`}
                    >
                      {selectedPlatform === "facebook" ||
                      selectedPlatform === "instagram" ? (
                        <div className="border rounded-lg overflow-hidden bg-white">
                          {/* Social Feed Ad Preview */}
                          <div className="p-3 border-b bg-gray-50">
                            <div className="flex items-center gap-3">
                              <Avatar className="h-8 w-8">
                                <AvatarFallback className="bg-blue-500 text-white">
                                  {businessName?.charAt(0) || "B"}
                                </AvatarFallback>
                              </Avatar>
                              <div>
                                <p className="font-semibold text-sm">
                                  {businessName || "Your Business"}
                                </p>
                                <p className="text-xs text-gray-500">
                                  Sponsored
                                </p>
                              </div>
                            </div>
                          </div>

                          {adCreatives[0]?.mediaUrls.length > 0 && (
                            <div className="aspect-square bg-gray-100">
                              <img
                                src={adCreatives[0].mediaUrls[0]}
                                alt="Ad creative"
                                className="w-full h-full object-cover"
                              />
                            </div>
                          )}

                          <div className="p-3">
                            <p className="font-semibold text-sm mb-1">
                              {adCreatives[0]?.headline ||
                                "Your compelling headline will appear here"}
                            </p>
                            <p className="text-sm text-gray-600 mb-3">
                              {adCreatives[0]?.description ||
                                "Your ad description will engage potential customers..."}
                            </p>
                            <Button size="sm" className="w-full">
                              {adCreatives[0]?.cta || "Learn More"}
                            </Button>
                          </div>

                          <div className="p-3 border-t bg-gray-50 flex items-center justify-around text-sm text-gray-600">
                            <div className="flex items-center gap-1">
                              <ThumbsUp className="h-4 w-4" />
                              Like
                            </div>
                            <div className="flex items-center gap-1">
                              <MessageSquare className="h-4 w-4" />
                              Comment
                            </div>
                            <div className="flex items-center gap-1">
                              <Share2 className="h-4 w-4" />
                              Share
                            </div>
                          </div>
                        </div>
                      ) : selectedPlatform === "google-search" ? (
                        <div className="border rounded-lg p-4 bg-white">
                          <div className="space-y-2">
                            <div className="text-xs text-green-600 bg-yellow-100 px-2 py-1 rounded inline-block">
                              Ad
                            </div>
                            <div className="text-blue-600 text-lg font-medium hover:underline cursor-pointer">
                              {adCreatives[0]?.headline ||
                                `${businessName} - Professional Services`}
                            </div>
                            <div className="text-green-700 text-sm">
                              www.yourbusiness.com
                            </div>
                            <div className="text-gray-700 text-sm">
                              {adCreatives[0]?.description ||
                                `Professional ${productService || "service"} with excellent reviews. ${specialOffer ? `Get ${specialOffer} now!` : "Call today for special prices!"}`}
                            </div>
                          </div>
                        </div>
                      ) : (
                        <div className="text-center py-12 text-muted-foreground">
                          <Monitor className="w-16 h-16 mx-auto mb-4 opacity-50" />
                          <p>Select a platform to see ad preview</p>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>

                {/* Performance Insights */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg flex items-center gap-2">
                      <BarChart3 className="h-5 w-5" />
                      Performance Insights
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {selectedPlatformData && (
                      <div className="grid grid-cols-2 gap-4">
                        <div className="text-center p-3 bg-muted/30 rounded-lg">
                          <p className="text-lg font-bold text-blue-600">
                            {selectedPlatformData.avgCTR}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            Avg Click Rate
                          </p>
                        </div>
                        <div className="text-center p-3 bg-muted/30 rounded-lg">
                          <p className="text-lg font-bold text-green-600">
                            {selectedPlatformData.avgCPC}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            Avg Cost per Click
                          </p>
                        </div>
                      </div>
                    )}

                    <div className="space-y-3">
                      <div className="flex justify-between text-sm">
                        <span>Audience Quality</span>
                        <span className="text-green-600">Excellent</span>
                      </div>
                      <Progress value={92} className="h-2" />

                      <div className="flex justify-between text-sm">
                        <span>Competition Level</span>
                        <span className="text-orange-600">Medium</span>
                      </div>
                      <Progress value={65} className="h-2" />

                      <div className="flex justify-between text-sm">
                        <span>Optimization Score</span>
                        <span className="text-blue-600">Good</span>
                      </div>
                      <Progress value={78} className="h-2" />
                    </div>

                    <div className="text-xs text-muted-foreground space-y-1">
                      <p>💡 Optimization tips:</p>
                      <ul className="list-disc list-inside space-y-1 ml-2">
                        <li>Add high-quality images for better engagement</li>
                        <li>Use local language for regional targeting</li>
                        <li>Include location-specific offers</li>
                        <li>Test multiple ad variations</li>
                      </ul>
                    </div>
                  </CardContent>
                </Card>

                {/* Market Insights */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg flex items-center gap-2">
                      <Lightbulb className="h-5 w-5" />
                      Market Insights
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="p-3 bg-blue-50 rounded-lg">
                      <p className="text-sm font-medium mb-1">Peak Hours</p>
                      <p className="text-xs text-muted-foreground">
                        Best performance: 7-9 PM for {selectedMarketTier.name}
                      </p>
                    </div>

                    <div className="p-3 bg-green-50 rounded-lg">
                      <p className="text-sm font-medium mb-1">
                        Trending Keywords
                      </p>
                      <div className="flex flex-wrap gap-1">
                        {getHashtags(currentLanguage.code)
                          .slice(0, 3)
                          .map((tag, idx) => (
                            <Badge
                              key={idx}
                              variant="outline"
                              className="text-xs"
                            >
                              {tag}
                            </Badge>
                          ))}
                      </div>
                    </div>

                    <div className="p-3 bg-orange-50 rounded-lg">
                      <p className="text-sm font-medium mb-1">
                        Competition Alert
                      </p>
                      <p className="text-xs text-muted-foreground">
                        High competition for "{productService}" in your area
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="assets" className="space-y-6">
            {/* Media Asset Library */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <ImageIcon className="h-5 w-5 text-purple-500" />
                  Media Asset Library
                </CardTitle>
                <CardDescription>
                  Upload and manage images, videos, and other creative assets
                  for your ads
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Upload Zone */}
                <div className="border-2 border-dashed border-purple-300 rounded-lg p-8 hover:border-purple-400 transition-colors">
                  <input
                    type="file"
                    accept="image/*,video/*"
                    multiple
                    onChange={(e) =>
                      e.target.files && handleAssetUpload(e.target.files)
                    }
                    className="hidden"
                    id="asset-upload"
                  />
                  <Label
                    htmlFor="asset-upload"
                    className="cursor-pointer flex flex-col items-center gap-4 text-center hover:text-purple-600"
                  >
                    <div className="p-6 bg-purple-100 rounded-full">
                      <Upload className="h-12 w-12 text-purple-600" />
                    </div>
                    <div>
                      <p className="text-xl font-medium">Upload Ad Assets</p>
                      <p className="text-muted-foreground mt-2">
                        Click to upload or drag & drop your images and videos
                      </p>
                      <p className="text-sm text-muted-foreground mt-1">
                        Supported: JPG, PNG, MP4, MOV • Max 100MB per file
                      </p>
                    </div>
                  </Label>
                </div>

                {/* Upload Progress */}
                {isUploadingAssets && (
                  <div className="flex items-center gap-3 p-4 bg-purple-50 rounded-lg">
                    <RefreshCw className="h-5 w-5 animate-spin text-purple-500" />
                    <div>
                      <p className="font-medium">Processing assets...</p>
                      <p className="text-sm text-muted-foreground">
                        Optimizing for different ad formats
                      </p>
                    </div>
                  </div>
                )}

                {/* Asset Grid */}
                {uploadedAssets.length > 0 && (
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <h3 className="text-lg font-semibold">
                        Your Assets ({uploadedAssets.length})
                      </h3>
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm">
                          <Filter className="h-4 w-4 mr-2" />
                          Filter
                        </Button>
                        <Button variant="outline" size="sm">
                          <Download className="h-4 w-4 mr-2" />
                          Export All
                        </Button>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                      {uploadedAssets.map((asset) => (
                        <Card
                          key={asset.id}
                          className="overflow-hidden group hover:shadow-lg transition-shadow"
                        >
                          <div className="aspect-square relative">
                            {asset.type === "video" ? (
                              <div className="w-full h-full bg-gray-100 flex items-center justify-center">
                                <div className="text-center">
                                  <Video className="h-8 w-8 mx-auto mb-2 text-gray-500" />
                                  <p className="text-xs font-medium">
                                    {asset.name}
                                  </p>
                                  {asset.duration && (
                                    <p className="text-xs text-muted-foreground">
                                      {asset.duration}s
                                    </p>
                                  )}
                                </div>
                              </div>
                            ) : (
                              <img
                                src={asset.url}
                                alt={asset.name}
                                className="w-full h-full object-cover"
                              />
                            )}

                            {/* Asset Actions */}
                            <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                              <Button variant="secondary" size="sm">
                                <Eye className="h-4 w-4" />
                              </Button>
                              <Button variant="secondary" size="sm">
                                <Edit3 className="h-4 w-4" />
                              </Button>
                              <Button
                                variant="secondary"
                                size="sm"
                                onClick={() => removeAsset(asset.id)}
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>

                            {/* Asset Type Badge */}
                            <div className="absolute top-2 left-2">
                              <Badge variant="secondary" className="text-xs">
                                {asset.type === "video" && (
                                  <Video className="h-3 w-3 mr-1" />
                                )}
                                {asset.type === "image" && (
                                  <ImageIcon className="h-3 w-3 mr-1" />
                                )}
                                {asset.type.toUpperCase()}
                              </Badge>
                            </div>
                          </div>

                          <CardContent className="p-3">
                            <p className="text-sm font-medium truncate">
                              {asset.name}
                            </p>
                            <div className="text-xs text-muted-foreground mt-1">
                              <p>{(asset.size / 1024 / 1024).toFixed(1)} MB</p>
                              {asset.dimensions && (
                                <p>
                                  {asset.dimensions.width} ×{" "}
                                  {asset.dimensions.height}
                                </p>
                              )}
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </div>
                )}

                {/* Asset Guidelines */}
                <Card className="bg-gradient-to-r from-blue-50 to-purple-50">
                  <CardHeader>
                    <CardTitle className="text-lg">Asset Guidelines</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid md:grid-cols-2 gap-4 text-sm">
                      <div>
                        <h4 className="font-semibold mb-2">
                          Image Requirements
                        </h4>
                        <ul className="space-y-1 text-muted-foreground">
                          <li>• Facebook/Instagram: 1080 × 1080px (square)</li>
                          <li>• Google Display: 728 × 90px (banner)</li>
                          <li>• Format: JPG, PNG</li>
                          <li>• Max size: 30MB</li>
                        </ul>
                      </div>
                      <div>
                        <h4 className="font-semibold mb-2">
                          Video Requirements
                        </h4>
                        <ul className="space-y-1 text-muted-foreground">
                          <li>• Duration: 15-60 seconds recommended</li>
                          <li>• Format: MP4, MOV</li>
                          <li>• Aspect ratio: 1:1 or 16:9</li>
                          <li>• Max size: 4GB</li>
                        </ul>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="campaigns" className="space-y-6">
            {/* Campaign Performance Table */}
            <Card>
              <CardHeader>
                <CardTitle>Active Campaigns</CardTitle>
                <CardDescription>
                  Monitor and manage your advertising campaigns across all
                  platforms
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Campaign</TableHead>
                      <TableHead>Platform</TableHead>
                      <TableHead>Objective</TableHead>
                      <TableHead>Budget</TableHead>
                      <TableHead>Performance</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {campaigns.map((campaign) => {
                      const platform = adPlatforms.find(
                        (p) => p.id === campaign.platform,
                      );
                      const objective = adObjectives.find(
                        (o) => o.id === campaign.objective,
                      );
                      const PlatformIcon = platform?.icon || Globe;
                      const ObjectiveIcon = objective?.icon || Target;

                      return (
                        <TableRow key={campaign.id}>
                          <TableCell>
                            <div className="flex items-center gap-3">
                              <div
                                className={`p-2 rounded ${platform?.color || "bg-gray-500"} text-white`}
                              >
                                <PlatformIcon className="h-4 w-4" />
                              </div>
                              <div>
                                <p className="font-medium">{campaign.name}</p>
                                <p className="text-sm text-muted-foreground">
                                  {campaign.adCopy.headline}
                                </p>
                                <div className="flex items-center gap-2 mt-1">
                                  <Badge variant="outline" className="text-xs">
                                    {campaign.language.toUpperCase()}
                                  </Badge>
                                  {campaign.mediaUrls.length > 0 && (
                                    <Badge
                                      variant="secondary"
                                      className="text-xs"
                                    >
                                      {campaign.mediaUrls.length} media
                                    </Badge>
                                  )}
                                </div>
                              </div>
                            </div>
                          </TableCell>
                          <TableCell>
                            <Badge variant="outline">{platform?.name}</Badge>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <ObjectiveIcon className="h-4 w-4 text-muted-foreground" />
                              <span className="text-sm">{objective?.name}</span>
                            </div>
                          </TableCell>
                          <TableCell>
                            <div>
                              <p className="font-medium">
                                ₹{campaign.budget.toLocaleString()}
                              </p>
                              <p className="text-sm text-muted-foreground">
                                ₹{campaign.spent.toLocaleString()} spent
                              </p>
                              <Progress
                                value={(campaign.spent / campaign.budget) * 100}
                                className="w-16 h-1 mt-1"
                              />
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="space-y-1">
                              <div className="flex justify-between text-sm">
                                <span>CTR:</span>
                                <span className="font-medium">
                                  {campaign.ctr.toFixed(2)}%
                                </span>
                              </div>
                              <div className="flex justify-between text-sm">
                                <span>CPC:</span>
                                <span className="font-medium">
                                  ₹{campaign.cpc.toFixed(2)}
                                </span>
                              </div>
                              <div className="flex justify-between text-sm">
                                <span>Conv:</span>
                                <span className="font-medium">
                                  {campaign.conversions}
                                </span>
                              </div>
                            </div>
                          </TableCell>
                          <TableCell>
                            <Badge
                              variant={
                                campaign.status === "active"
                                  ? "default"
                                  : campaign.status === "paused"
                                    ? "secondary"
                                    : campaign.status === "completed"
                                      ? "outline"
                                      : "secondary"
                              }
                              className="flex items-center gap-1 w-fit"
                            >
                              {campaign.status === "active" && (
                                <Play className="h-3 w-3" />
                              )}
                              {campaign.status === "paused" && (
                                <Pause className="h-3 w-3" />
                              )}
                              {campaign.status === "completed" && (
                                <CheckCircle className="h-3 w-3" />
                              )}
                              {campaign.status}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <Dialog>
                                <DialogTrigger asChild>
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    onClick={() =>
                                      setSelectedCampaign(campaign)
                                    }
                                  >
                                    <Eye className="h-3 w-3" />
                                  </Button>
                                </DialogTrigger>
                                <DialogContent className="max-w-4xl">
                                  <DialogHeader>
                                    <DialogTitle>
                                      Campaign Analytics - {campaign.name}
                                    </DialogTitle>
                                    <DialogDescription>
                                      Detailed performance metrics and insights
                                    </DialogDescription>
                                  </DialogHeader>
                                  {selectedCampaign && (
                                    <div className="grid grid-cols-2 gap-6">
                                      <div className="space-y-4">
                                        <div>
                                          <h4 className="font-semibold mb-3">
                                            Performance Overview
                                          </h4>
                                          <div className="grid grid-cols-2 gap-3">
                                            <div className="p-3 bg-muted/30 rounded text-center">
                                              <p className="text-lg font-bold">
                                                {selectedCampaign.impressions.toLocaleString()}
                                              </p>
                                              <p className="text-xs text-muted-foreground">
                                                Impressions
                                              </p>
                                            </div>
                                            <div className="p-3 bg-muted/30 rounded text-center">
                                              <p className="text-lg font-bold">
                                                {selectedCampaign.clicks.toLocaleString()}
                                              </p>
                                              <p className="text-xs text-muted-foreground">
                                                Clicks
                                              </p>
                                            </div>
                                            <div className="p-3 bg-muted/30 rounded text-center">
                                              <p className="text-lg font-bold">
                                                {selectedCampaign.ctr.toFixed(
                                                  2,
                                                )}
                                                %
                                              </p>
                                              <p className="text-xs text-muted-foreground">
                                                CTR
                                              </p>
                                            </div>
                                            <div className="p-3 bg-muted/30 rounded text-center">
                                              <p className="text-lg font-bold">
                                                {selectedCampaign.conversions}
                                              </p>
                                              <p className="text-xs text-muted-foreground">
                                                Conversions
                                              </p>
                                            </div>
                                          </div>
                                        </div>

                                        <div>
                                          <h4 className="font-semibold mb-2">
                                            Ad Copy
                                          </h4>
                                          <div className="p-3 bg-muted/30 rounded space-y-2">
                                            <div>
                                              <span className="text-sm font-medium">
                                                Headline:{" "}
                                              </span>
                                              <span className="text-sm">
                                                {
                                                  selectedCampaign.adCopy
                                                    .headline
                                                }
                                              </span>
                                            </div>
                                            <div>
                                              <span className="text-sm font-medium">
                                                Description:{" "}
                                              </span>
                                              <span className="text-sm">
                                                {
                                                  selectedCampaign.adCopy
                                                    .description
                                                }
                                              </span>
                                            </div>
                                            <div>
                                              <span className="text-sm font-medium">
                                                CTA:{" "}
                                              </span>
                                              <span className="text-sm">
                                                {selectedCampaign.adCopy.cta}
                                              </span>
                                            </div>
                                          </div>
                                        </div>
                                      </div>

                                      <div className="space-y-4">
                                        <div>
                                          <h4 className="font-semibold mb-2">
                                            Budget Performance
                                          </h4>
                                          <div className="p-4 bg-green-50 rounded-lg">
                                            <div className="flex justify-between items-center mb-2">
                                              <span>Budget Utilization</span>
                                              <span className="font-semibold">
                                                {(
                                                  (selectedCampaign.spent /
                                                    selectedCampaign.budget) *
                                                  100
                                                ).toFixed(1)}
                                                %
                                              </span>
                                            </div>
                                            <Progress
                                              value={
                                                (selectedCampaign.spent /
                                                  selectedCampaign.budget) *
                                                100
                                              }
                                              className="h-2 mb-2"
                                            />
                                            <div className="flex justify-between text-sm text-muted-foreground">
                                              <span>
                                                ₹
                                                {selectedCampaign.spent.toLocaleString()}{" "}
                                                spent
                                              </span>
                                              <span>
                                                ₹
                                                {selectedCampaign.budget.toLocaleString()}{" "}
                                                total
                                              </span>
                                            </div>
                                          </div>
                                        </div>

                                        <div>
                                          <h4 className="font-semibold mb-2">
                                            Campaign Details
                                          </h4>
                                          <div className="space-y-2 text-sm">
                                            <div className="flex justify-between">
                                              <span>Platform:</span>
                                              <span>
                                                {
                                                  adPlatforms.find(
                                                    (p) =>
                                                      p.id ===
                                                      selectedCampaign.platform,
                                                  )?.name
                                                }
                                              </span>
                                            </div>
                                            <div className="flex justify-between">
                                              <span>Objective:</span>
                                              <span>
                                                {
                                                  adObjectives.find(
                                                    (o) =>
                                                      o.id ===
                                                      selectedCampaign.objective,
                                                  )?.name
                                                }
                                              </span>
                                            </div>
                                            <div className="flex justify-between">
                                              <span>Language:</span>
                                              <span>
                                                {selectedCampaign.language.toUpperCase()}
                                              </span>
                                            </div>
                                            <div className="flex justify-between">
                                              <span>Created:</span>
                                              <span>
                                                {selectedCampaign.createdAt}
                                              </span>
                                            </div>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  )}
                                </DialogContent>
                              </Dialog>

                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => duplicateCampaign(campaign.id)}
                              >
                                <Copy className="h-3 w-3" />
                              </Button>

                              <Button variant="outline" size="sm">
                                <Edit3 className="h-3 w-3" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="analytics" className="space-y-6">
            {/* Analytics Overview */}
            <div className="grid gap-6 md:grid-cols-4">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">
                    Total Spend
                  </CardTitle>
                  <IndianRupee className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    ₹
                    {campaigns
                      .reduce((total, c) => total + c.spent, 0)
                      .toLocaleString()}
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Start advertising to see growth metrics
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">
                    Total Impressions
                  </CardTitle>
                  <Eye className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    {campaigns
                      .reduce((total, c) => total + c.impressions, 0)
                      .toLocaleString()}
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Start campaigns to track impressions
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">
                    Total Clicks
                  </CardTitle>
                  <MousePointer className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    {campaigns
                      .reduce((total, c) => total + c.clicks, 0)
                      .toLocaleString()}
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Launch ads to see click metrics
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Avg CTR</CardTitle>
                  <Target className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    {campaigns.length > 0
                      ? (
                          campaigns.reduce((total, c) => total + c.ctr, 0) /
                          campaigns.length
                        ).toFixed(2)
                      : 0}
                    %
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Run campaigns to track CTR performance
                  </p>
                </CardContent>
              </Card>
            </div>

            {/* Platform Comparison */}
            <Card>
              <CardHeader>
                <CardTitle>Performance by Platform</CardTitle>
                <CardDescription>
                  Compare advertising performance across different platforms
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {adPlatforms.map((platform) => {
                    const PlatformIcon = platform.icon;
                    const platformCampaigns = campaigns.filter(
                      (c) => c.platform === platform.id,
                    );
                    const totalSpent = platformCampaigns.reduce(
                      (sum, c) => sum + c.spent,
                      0,
                    );
                    const totalClicks = platformCampaigns.reduce(
                      (sum, c) => sum + c.clicks,
                      0,
                    );
                    const avgCTR =
                      platformCampaigns.length > 0
                        ? platformCampaigns.reduce((sum, c) => sum + c.ctr, 0) /
                          platformCampaigns.length
                        : 0;

                    return (
                      <div key={platform.id} className="p-4 border rounded-lg">
                        <div className="flex items-center justify-between mb-4">
                          <div className="flex items-center gap-3">
                            <div
                              className={`p-3 rounded ${platform.color} text-white`}
                            >
                              <PlatformIcon className="h-5 w-5" />
                            </div>
                            <div>
                              <span className="font-medium">
                                {platform.name}
                              </span>
                              <p className="text-sm text-muted-foreground">
                                {platformCampaigns.length} active campaign
                                {platformCampaigns.length !== 1 ? "s" : ""}
                              </p>
                            </div>
                          </div>
                          <Badge variant="outline">
                            {avgCTR.toFixed(2)}% CTR
                          </Badge>
                        </div>

                        <div className="grid grid-cols-4 gap-4 text-center">
                          <div>
                            <p className="text-xl font-bold">
                              ₹{totalSpent.toLocaleString()}
                            </p>
                            <p className="text-sm text-muted-foreground">
                              Spent
                            </p>
                          </div>
                          <div>
                            <p className="text-xl font-bold">
                              {totalClicks.toLocaleString()}
                            </p>
                            <p className="text-sm text-muted-foreground">
                              Clicks
                            </p>
                          </div>
                          <div>
                            <p className="text-xl font-bold">
                              {platform.avgCPC}
                            </p>
                            <p className="text-sm text-muted-foreground">
                              Avg CPC
                            </p>
                          </div>
                          <div>
                            <p className="text-xl font-bold">
                              {platform.reachPotential}
                            </p>
                            <p className="text-sm text-muted-foreground">
                              Reach Potential
                            </p>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="audiences" className="space-y-6">
            {/* Audience Management */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="h-5 w-5 text-green-500" />
                  Audience Targeting
                </CardTitle>
                <CardDescription>
                  Define and manage your target audiences for better ad
                  performance
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Demographics */}
                <div className="space-y-4">
                  <h4 className="font-semibold">Demographics</h4>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Age Range</Label>
                      <div className="flex items-center gap-2">
                        <Input
                          type="number"
                          placeholder="18"
                          value={targetAudience.ageMin}
                          onChange={(e) =>
                            setTargetAudience((prev) => ({
                              ...prev,
                              ageMin: parseInt(e.target.value) || 18,
                            }))
                          }
                          className="w-20"
                        />
                        <span>to</span>
                        <Input
                          type="number"
                          placeholder="65"
                          value={targetAudience.ageMax}
                          onChange={(e) =>
                            setTargetAudience((prev) => ({
                              ...prev,
                              ageMax: parseInt(e.target.value) || 65,
                            }))
                          }
                          className="w-20"
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label>Gender</Label>
                      <Select
                        value={targetAudience.gender}
                        onValueChange={(value) =>
                          setTargetAudience((prev) => ({
                            ...prev,
                            gender: value,
                          }))
                        }
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">All Genders</SelectItem>
                          <SelectItem value="male">Male</SelectItem>
                          <SelectItem value="female">Female</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </div>

                {/* Targeting Options */}
                <div className="space-y-4">
                  <h4 className="font-semibold">Targeting Options</h4>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                    {targetingOptions.map((option) => {
                      const IconComponent = option.icon;
                      return (
                        <Card
                          key={option.id}
                          className="cursor-pointer hover:shadow-md transition-shadow"
                        >
                          <CardContent className="p-4">
                            <div className="flex items-center gap-3">
                              <IconComponent className="h-5 w-5 text-primary" />
                              <span className="font-medium text-sm">
                                {option.name}
                              </span>
                            </div>
                          </CardContent>
                        </Card>
                      );
                    })}
                  </div>
                </div>

                {/* Audience Insights */}
                <div className="p-4 bg-blue-50 rounded-lg">
                  <h4 className="font-semibold mb-3">Audience Insights</h4>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                    <div className="text-center">
                      <p className="text-lg font-bold text-blue-600">2.5M</p>
                      <p className="text-muted-foreground">Potential Reach</p>
                    </div>
                    <div className="text-center">
                      <p className="text-lg font-bold text-green-600">₹15-25</p>
                      <p className="text-muted-foreground">Est. CPC Range</p>
                    </div>
                    <div className="text-center">
                      <p className="text-lg font-bold text-orange-600">High</p>
                      <p className="text-muted-foreground">Competition</p>
                    </div>
                    <div className="text-center">
                      <p className="text-lg font-bold text-purple-600">85%</p>
                      <p className="text-muted-foreground">Mobile Users</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="insights" className="space-y-6">
            {/* Market Insights */}
            <div className="grid gap-6 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <TrendingUp className="h-5 w-5 text-green-500" />
                    Market Trends
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="p-3 bg-green-50 rounded-lg">
                    <p className="font-medium text-sm mb-1">Growing Demand</p>
                    <p className="text-xs text-muted-foreground">
                      45% increase in searches for "{productService}" in{" "}
                      {selectedMarketTier.name}
                    </p>
                  </div>

                  <div className="p-3 bg-blue-50 rounded-lg">
                    <p className="font-medium text-sm mb-1">
                      Peak Shopping Hours
                    </p>
                    <p className="text-xs text-muted-foreground">
                      Best performance between 7-9 PM for your target audience
                    </p>
                  </div>

                  <div className="p-3 bg-purple-50 rounded-lg">
                    <p className="font-medium text-sm mb-1">
                      Seasonal Opportunity
                    </p>
                    <p className="text-xs text-muted-foreground">
                      Festival season approaching - 70% higher conversion rates
                      expected
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Target className="h-5 w-5 text-blue-500" />
                    Competitor Analysis
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="p-3 bg-orange-50 rounded-lg">
                    <p className="font-medium text-sm mb-1">
                      Competition Level
                    </p>
                    <p className="text-xs text-muted-foreground">
                      Medium competition in your category with average CPC of
                      ₹18-35
                    </p>
                  </div>

                  <div className="p-3 bg-red-50 rounded-lg">
                    <p className="font-medium text-sm mb-1">
                      Market Saturation
                    </p>
                    <p className="text-xs text-muted-foreground">
                      65% market penetration - focus on unique value
                      propositions
                    </p>
                  </div>

                  <div className="p-3 bg-teal-50 rounded-lg">
                    <p className="font-medium text-sm mb-1">Opportunity Gap</p>
                    <p className="text-xs text-muted-foreground">
                      Limited regional language advertising - high potential for
                      growth
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Trending Keywords */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Search className="h-5 w-5 text-purple-500" />
                  Trending Keywords for {currentLanguage.nativeName}
                </CardTitle>
                <CardDescription>
                  High-performing keywords in your market segment
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4 md:grid-cols-3">
                  {getHashtags(currentLanguage.code)
                    .slice(0, 9)
                    .map((keyword, index) => (
                      <div
                        key={index}
                        className="flex items-center justify-between p-3 border rounded-lg"
                      >
                        <span className="font-medium">{keyword}</span>
                        <div className="flex items-center gap-2">
                          <Badge variant="outline" className="text-xs">
                            ₹{(Math.random() * 30 + 10).toFixed(0)} CPC
                          </Badge>
                          <Button size="sm" variant="outline">
                            <Plus className="h-3 w-3" />
                          </Button>
                        </div>
                      </div>
                    ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  );
}

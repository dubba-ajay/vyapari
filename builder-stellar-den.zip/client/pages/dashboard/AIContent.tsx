import React, { useState } from "react";
import { DashboardLayout } from "@/components/DashboardLayout";
import { useLanguage } from "@/hooks/useLanguage";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Zap,
  Copy,
  Download,
  Share,
  Sparkles,
  Globe,
  Clock,
  History,
  TrendingUp,
} from "lucide-react";
import {
  getContentTemplate,
  formatContent,
  getCTA,
  getHashtags,
  SUPPORTED_LANGUAGES,
} from "@/lib/regionalLanguage";

const contentTypes = [
  {
    id: "business_promotion",
    name: "Business Promotion",
    description: "Promote your business services",
  },
  {
    id: "product_showcase",
    name: "Product Showcase",
    description: "Highlight specific products",
  },
  {
    id: "festival_greeting",
    name: "Festival Greeting",
    description: "Regional festival wishes",
  },
  {
    id: "promotional",
    name: "Promotional Content",
    description: "Special offers and deals",
  },
  {
    id: "educational",
    name: "Educational Content",
    description: "Informative posts",
  },
  {
    id: "testimonial",
    name: "Customer Testimonial",
    description: "Customer success stories",
  },
];

const tones = [
  { id: "professional", name: "Professional" },
  { id: "friendly", name: "Friendly" },
  { id: "casual", name: "Casual" },
  { id: "exciting", name: "Exciting" },
  { id: "informative", name: "Informative" },
  { id: "cultural", name: "Cultural/Traditional" },
];

const platforms = [
  { id: "social", name: "Social Media", maxLength: 280 },
  { id: "whatsapp", name: "WhatsApp", maxLength: 1000 },
  { id: "email", name: "Email", maxLength: 2000 },
  { id: "ads", name: "Ad Copy", maxLength: 150 },
];

export default function AIContent() {
  const { currentLanguage, selectedMarketTier } = useLanguage();
  const [contentType, setContentType] = useState("business_promotion");
  const [platform, setPlatform] = useState("social");
  const [topic, setTopic] = useState("");
  const [tone, setTone] = useState("professional");
  const [businessName, setBusinessName] = useState("");
  const [includeHashtags, setIncludeHashtags] = useState(true);
  const [includeEmojis, setIncludeEmojis] = useState(true);
  const [includeCallToAction, setIncludeCallToAction] = useState(true);
  const [includeContactInfo, setIncludeContactInfo] = useState(false);
  const [generatedContent, setGeneratedContent] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);
  const [contentHistory, setContentHistory] = useState<
    Array<{
      id: number;
      content: string;
      type: string;
      language: string;
      timestamp: string;
    }>
  >([]);

  const handleGenerate = async () => {
    setIsGenerating(true);

    // Simulate AI content generation delay
    await new Promise((resolve) => setTimeout(resolve, 2000));

    try {
      // Get base template for the content type and language
      const template = getContentTemplate(
        platform as any,
        currentLanguage.code,
        contentType,
      );
      const hashtags = getHashtags(currentLanguage.code);
      const cta = getCTA(currentLanguage.code, "contact");

      // Prepare variables for template replacement
      const variables = {
        businessName: businessName || "Your Business",
        topic: topic || "quality services",
        marketTier: selectedMarketTier.name,
        festival: "Festival Name", // This would be dynamic based on upcoming festivals
      };

      // Format the base content
      let content = formatContent(template, variables);

      // Add optional elements based on user preferences
      const elements = [];

      if (includeCallToAction && cta) {
        elements.push(`\n\n${cta} 📞`);
      }

      if (includeContactInfo) {
        elements.push("\n📍 Visit us at [Your Business Address]");
        elements.push("\n📞 Call: +91 98765 43210");
      }

      if (includeHashtags && hashtags.length > 0) {
        elements.push(`\n\n${hashtags.slice(0, 5).join(" ")}`);
      }

      // Combine all elements
      const finalContent = content + elements.join("");

      setGeneratedContent(finalContent);

      // Add to history
      const newHistoryItem = {
        id: Date.now(),
        content: finalContent,
        type: contentType,
        language: currentLanguage.code,
        timestamp: new Date().toLocaleString(),
      };
      setContentHistory((prev) => [newHistoryItem, ...prev.slice(0, 9)]); // Keep last 10 items
    } catch (error) {
      console.error("Error generating content:", error);
      setGeneratedContent(
        "Sorry, there was an error generating content. Please try again.",
      );
    }

    setIsGenerating(false);
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(generatedContent);
  };

  const getLanguageName = (code: string) => {
    const language = SUPPORTED_LANGUAGES.find((lang) => lang.code === code);
    return language ? language.nativeName : code;
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Page Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">
              AI Content Studio
            </h1>
            <p className="text-muted-foreground">
              Generate marketing content in {currentLanguage.nativeName} for{" "}
              {selectedMarketTier.name}
            </p>
          </div>
          <div className="flex items-center gap-2">
            <Badge variant="outline" className="gap-2">
              <Globe className="h-4 w-4" />
              {currentLanguage.nativeName}
            </Badge>
            <Badge className="bg-gradient-to-r from-brand-orange-500 to-brand-blue-500 text-white gap-2">
              <Sparkles className="w-4 h-4" />
              AI Powered
            </Badge>
          </div>
        </div>

        <Tabs defaultValue="create" className="space-y-6">
          <TabsList>
            <TabsTrigger value="create">Create Content</TabsTrigger>
            <TabsTrigger value="history">History</TabsTrigger>
            <TabsTrigger value="templates">Templates</TabsTrigger>
          </TabsList>

          <TabsContent value="create">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Input Form */}
              <div className="lg:col-span-2">
                <Card>
                  <CardHeader>
                    <CardTitle>Content Settings</CardTitle>
                    <CardDescription>
                      Configure your content parameters for{" "}
                      {currentLanguage.nativeName}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="platform">Platform</Label>
                        <Select value={platform} onValueChange={setPlatform}>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {platforms.map((p) => (
                              <SelectItem key={p.id} value={p.id}>
                                {p.name} (max {p.maxLength} chars)
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="contentType">Content Type</Label>
                        <Select
                          value={contentType}
                          onValueChange={setContentType}
                        >
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {contentTypes.map((type) => (
                              <SelectItem key={type.id} value={type.id}>
                                <div>
                                  <div className="font-medium">{type.name}</div>
                                  <div className="text-xs text-muted-foreground">
                                    {type.description}
                                  </div>
                                </div>
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="businessName">Business Name</Label>
                        <Input
                          id="businessName"
                          placeholder="Enter your business name"
                          value={businessName}
                          onChange={(e) => setBusinessName(e.target.value)}
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="tone">Tone</Label>
                        <Select value={tone} onValueChange={setTone}>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {tones.map((t) => (
                              <SelectItem key={t.id} value={t.id}>
                                {t.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="topic">Topic/Product/Service</Label>
                      <Input
                        id="topic"
                        placeholder={`e.g., ${currentLanguage.code === "hi" ? "नए उत्पाद लॉन्च, दीवाली सेल" : currentLanguage.code === "te" ? "కొత్త ఉత్పత్తులు, దీపావళి సేల్" : "New product launch, Diwali sale"}`}
                        value={topic}
                        onChange={(e) => setTopic(e.target.value)}
                      />
                    </div>

                    <Separator />

                    <div className="space-y-4">
                      <Label className="text-base font-semibold">
                        Include Elements
                      </Label>
                      <div className="grid grid-cols-2 gap-4">
                        <div className="flex items-center space-x-2">
                          <Checkbox
                            id="hashtags"
                            checked={includeHashtags}
                            onCheckedChange={setIncludeHashtags}
                          />
                          <Label htmlFor="hashtags">Regional Hashtags</Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Checkbox
                            id="emojis"
                            checked={includeEmojis}
                            onCheckedChange={setIncludeEmojis}
                          />
                          <Label htmlFor="emojis">Emojis</Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Checkbox
                            id="cta"
                            checked={includeCallToAction}
                            onCheckedChange={setIncludeCallToAction}
                          />
                          <Label htmlFor="cta">Call to Action</Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Checkbox
                            id="contact"
                            checked={includeContactInfo}
                            onCheckedChange={setIncludeContactInfo}
                          />
                          <Label htmlFor="contact">Contact Info</Label>
                        </div>
                      </div>
                    </div>

                    <Button
                      onClick={handleGenerate}
                      disabled={!contentType || !topic || isGenerating}
                      className="w-full bg-gradient-to-r from-brand-orange-500 to-brand-blue-500 hover:opacity-90"
                      size="lg"
                    >
                      {isGenerating ? (
                        <>
                          <Clock className="w-4 h-4 mr-2 animate-spin" />
                          Generating in {currentLanguage.nativeName}...
                        </>
                      ) : (
                        <>
                          <Zap className="w-4 h-4 mr-2" />
                          Generate Content
                        </>
                      )}
                    </Button>
                  </CardContent>
                </Card>
              </div>

              {/* Generated Content */}
              <div>
                <Card>
                  <CardHeader>
                    <CardTitle>Generated Content</CardTitle>
                    <CardDescription>
                      {generatedContent
                        ? `Content in ${currentLanguage.nativeName} - ${generatedContent.length} characters`
                        : "AI-generated content will appear here"}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    {generatedContent ? (
                      <div className="space-y-4">
                        <div className="bg-muted/50 p-4 rounded-lg">
                          <Textarea
                            value={generatedContent}
                            onChange={(e) =>
                              setGeneratedContent(e.target.value)
                            }
                            rows={12}
                            className={`border-0 bg-transparent resize-none ${currentLanguage.rtl ? "text-right" : ""}`}
                            style={{
                              direction: currentLanguage.rtl ? "rtl" : "ltr",
                            }}
                          />
                        </div>
                        <div className="flex flex-col gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={copyToClipboard}
                          >
                            <Copy className="w-4 h-4 mr-2" />
                            Copy Text
                          </Button>
                          <Button variant="outline" size="sm">
                            <Download className="w-4 h-4 mr-2" />
                            Save as Draft
                          </Button>
                          <Button variant="outline" size="sm">
                            <Share className="w-4 h-4 mr-2" />
                            Share to Platform
                          </Button>
                        </div>
                      </div>
                    ) : (
                      <div className="text-center py-8 text-muted-foreground">
                        <Zap className="w-12 h-12 mx-auto mb-4 opacity-50" />
                        <p>
                          Configure your content settings and click "Generate
                          Content" to create AI-powered content in{" "}
                          {currentLanguage.nativeName}.
                        </p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="history">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <History className="h-5 w-5" />
                  Content History
                </CardTitle>
                <CardDescription>
                  Previously generated content across all languages
                </CardDescription>
              </CardHeader>
              <CardContent>
                {contentHistory.length > 0 ? (
                  <div className="space-y-4">
                    {contentHistory.map((item) => (
                      <div key={item.id} className="border rounded-lg p-4">
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center gap-2">
                            <Badge variant="outline">
                              {getLanguageName(item.language)}
                            </Badge>
                            <Badge variant="secondary">
                              {
                                contentTypes.find((t) => t.id === item.type)
                                  ?.name
                              }
                            </Badge>
                          </div>
                          <span className="text-xs text-muted-foreground">
                            {item.timestamp}
                          </span>
                        </div>
                        <p className="text-sm line-clamp-3 mb-2">
                          {item.content}
                        </p>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => setGeneratedContent(item.content)}
                        >
                          Use This Content
                        </Button>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8 text-muted-foreground">
                    <History className="w-12 h-12 mx-auto mb-4 opacity-50" />
                    <p>
                      No content generated yet. Create your first piece of
                      content!
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="templates">
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {contentTypes.map((type) => (
                <Card
                  key={type.id}
                  className="cursor-pointer hover:shadow-md transition-shadow"
                  onClick={() => setContentType(type.id)}
                >
                  <CardHeader>
                    <CardTitle className="text-lg">{type.name}</CardTitle>
                    <CardDescription>{type.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <p className="text-sm text-muted-foreground">
                        Available in {SUPPORTED_LANGUAGES.length} languages
                      </p>
                      <Badge
                        variant="outline"
                        className="w-full justify-center"
                      >
                        Select Template
                      </Badge>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  );
}

import React, { useState } from "react";
import { DashboardLayout } from "@/components/DashboardLayout";
import { useLanguage } from "@/hooks/useLanguage";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Progress } from "@/components/ui/progress";
import {
  BarChart3,
  TrendingUp,
  Users,
  Eye,
  MousePointer,
  IndianRupee,
  Calendar,
  Target,
  Zap,
  ArrowRight,
  PlayCircle,
  ArrowUp,
  ArrowDown,
  Minus,
  Download,
  RefreshCw,
  MessageSquare,
  Share2,
  Heart,
  Phone,
  Mail,
  Globe,
  Map,
  Clock,
  Award,
  Filter,
  PieChart,
  LineChart,
  Activity,
  Smartphone,
  Monitor,
  Languages,
  Building,
} from "lucide-react";

interface AnalyticsData {
  totalReach: number;
  totalEngagement: number;
  totalLeads: number;
  totalRevenue: number;
  campaignsActive: number;
  avgEngagementRate: number;
  conversionRate: number;
  roi: number;
}

interface ChannelPerformance {
  channel: string;
  icon: any;
  reach: number;
  engagement: number;
  leads: number;
  cost: number;
  roi: number;
  trend: "up" | "down" | "stable";
}

interface LanguagePerformance {
  language: string;
  nativeName: string;
  reach: number;
  engagement: number;
  conversionRate: number;
  revenue: number;
  campaigns: number;
}

interface CampaignData {
  id: number;
  name: string;
  channel: string;
  language: string;
  status: "active" | "completed" | "paused";
  reach: number;
  engagement: number;
  leads: number;
  cost: number;
  revenue: number;
  startDate: string;
}

const mockAnalytics: AnalyticsData = {
  totalReach: 0,
  totalEngagement: 0,
  totalLeads: 0,
  totalRevenue: 0,
  campaignsActive: 0,
  avgEngagementRate: 0,
  conversionRate: 0,
  roi: 0,
};

const mockChannelPerformance: ChannelPerformance[] = [];

const mockLanguagePerformance: LanguagePerformance[] = [];

const mockCampaigns: CampaignData[] = [
  {
    id: 1,
    name: "Diwali Festival Campaign",
    channel: "WhatsApp",
    language: "hi",
    status: "active",
    reach: 15400,
    engagement: 1240,
    leads: 67,
    cost: 4500,
    revenue: 18600,
    startDate: "2024-01-10",
  },
  {
    id: 2,
    name: "Local Business Promotion",
    channel: "Facebook",
    language: "en",
    status: "active",
    reach: 12800,
    engagement: 890,
    leads: 34,
    cost: 3200,
    revenue: 12400,
    startDate: "2024-01-08",
  },
  {
    id: 3,
    name: "Regional Product Launch",
    channel: "Google Ads",
    language: "te",
    status: "completed",
    reach: 8900,
    engagement: 567,
    leads: 28,
    cost: 5600,
    revenue: 15800,
    startDate: "2024-01-05",
  },
];

const timeRanges = [
  { value: "7d", label: "Last 7 days" },
  { value: "30d", label: "Last 30 days" },
  { value: "90d", label: "Last 90 days" },
  { value: "12m", label: "Last 12 months" },
];

export default function Analytics() {
  const { currentLanguage, selectedMarketTier } = useLanguage();
  const [timeRange, setTimeRange] = useState("30d");
  const [selectedChannel, setSelectedChannel] = useState("all");
  const [selectedLanguage, setSelectedLanguage] = useState("all");

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case "up":
        return <ArrowUp className="h-4 w-4 text-green-600" />;
      case "down":
        return <ArrowDown className="h-4 w-4 text-red-600" />;
      default:
        return <Minus className="h-4 w-4 text-gray-600" />;
    }
  };

  const getTrendColor = (trend: string) => {
    switch (trend) {
      case "up":
        return "text-green-600";
      case "down":
        return "text-red-600";
      default:
        return "text-gray-600";
    }
  };

  const formatCurrency = (amount: number) => {
    return `₹${amount.toLocaleString()}`;
  };

  const formatNumber = (num: number) => {
    if (num >= 100000) return `${(num / 100000).toFixed(1)}L`;
    if (num >= 1000) return `${(num / 1000).toFixed(1)}K`;
    return num.toString();
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Page Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">
              Advanced Analytics
            </h1>
            <p className="text-muted-foreground">
              Multi-channel insights for {selectedMarketTier.name} in{" "}
              {currentLanguage.nativeName}
            </p>
          </div>
          <div className="flex items-center gap-2">
            <Select value={timeRange} onValueChange={setTimeRange}>
              <SelectTrigger className="w-[150px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {timeRanges.map((range) => (
                  <SelectItem key={range.value} value={range.value}>
                    {range.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button variant="outline" size="sm">
              <RefreshCw className="h-4 w-4 mr-2" />
              Refresh
            </Button>
            <Button variant="outline" size="sm">
              <Download className="h-4 w-4 mr-2" />
              Export
            </Button>
          </div>
        </div>

        {/* Overview Metrics */}
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Reach</CardTitle>
              <Eye className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {formatNumber(mockAnalytics.totalReach)}
              </div>
              <div className="flex items-center space-x-2 text-xs text-muted-foreground">
                <ArrowUp className="h-3 w-3 text-green-600" />
                <span className="text-green-600">+12.5%</span>
                <span>from last month</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                Engagement Rate
              </CardTitle>
              <MousePointer className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {mockAnalytics.avgEngagementRate}%
              </div>
              <div className="flex items-center space-x-2 text-xs text-muted-foreground">
                <ArrowUp className="h-3 w-3 text-green-600" />
                <span className="text-green-600">+2.1%</span>
                <span>from last month</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Leads</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {mockAnalytics.totalLeads}
              </div>
              <div className="flex items-center space-x-2 text-xs text-muted-foreground">
                <ArrowUp className="h-3 w-3 text-green-600" />
                <span className="text-green-600">+18.2%</span>
                <span>from last month</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                Revenue Generated
              </CardTitle>
              <IndianRupee className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {formatCurrency(mockAnalytics.totalRevenue)}
              </div>
              <div className="flex items-center space-x-2 text-xs text-muted-foreground">
                <ArrowUp className="h-3 w-3 text-green-600" />
                <span className="text-green-600">+24.8%</span>
                <span>from last month</span>
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="channels">Channels</TabsTrigger>
            <TabsTrigger value="languages">Languages</TabsTrigger>
            <TabsTrigger value="campaigns">Campaigns</TabsTrigger>
            <TabsTrigger value="insights">Insights</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <div className="grid gap-6 md:grid-cols-2">
              {/* Performance Summary */}
              <Card>
                <CardHeader>
                  <CardTitle>Performance Summary</CardTitle>
                  <CardDescription>
                    Key metrics for your marketing performance
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Conversion Rate</span>
                    <div className="flex items-center space-x-2">
                      <div className="w-24 h-2 bg-gray-200 rounded-full">
                        <div
                          className="h-full bg-blue-500 rounded-full"
                          style={{
                            width: `${mockAnalytics.conversionRate * 10}%`,
                          }}
                        />
                      </div>
                      <span className="text-sm font-medium">
                        {mockAnalytics.conversionRate}%
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">ROI</span>
                    <div className="flex items-center space-x-2">
                      <div className="w-24 h-2 bg-gray-200 rounded-full">
                        <div
                          className="h-full bg-green-500 rounded-full"
                          style={{
                            width: `${Math.min(mockAnalytics.roi * 20, 100)}%`,
                          }}
                        />
                      </div>
                      <span className="text-sm font-medium">
                        {mockAnalytics.roi}x
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">
                      Active Campaigns
                    </span>
                    <span className="text-sm font-medium">
                      {mockAnalytics.campaignsActive}
                    </span>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Cost per Lead</span>
                    <span className="text-sm font-medium">
                      ₹{Math.round(25100 / mockAnalytics.totalLeads)}
                    </span>
                  </div>
                </CardContent>
              </Card>

              {/* Market Tier Performance */}
              <Card>
                <CardHeader>
                  <CardTitle>Market Tier Performance</CardTitle>
                  <CardDescription>
                    Performance breakdown by Indian market segments
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {[
                      {
                        tier: "Metro Cities",
                        reach: 45200,
                        engagement: 8.2,
                        revenue: 34500,
                        color: "bg-blue-500",
                      },
                      {
                        tier: "Tier 1 Cities",
                        reach: 38400,
                        engagement: 7.8,
                        revenue: 28900,
                        color: "bg-green-500",
                      },
                      {
                        tier: "Tier 2 Cities",
                        reach: 28700,
                        engagement: 6.9,
                        revenue: 18200,
                        color: "bg-yellow-500",
                      },
                      {
                        tier: "Tier 3 Cities",
                        reach: 13130,
                        engagement: 5.4,
                        revenue: 4000,
                        color: "bg-purple-500",
                      },
                    ].map((item, index) => (
                      <div
                        key={index}
                        className="flex items-center justify-between"
                      >
                        <div className="flex items-center space-x-3">
                          <div
                            className={`w-3 h-3 rounded-full ${item.color}`}
                          />
                          <span className="text-sm font-medium">
                            {item.tier}
                          </span>
                        </div>
                        <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                          <span>Reach: {formatNumber(item.reach)}</span>
                          <span>Eng: {item.engagement}%</span>
                          <span>Rev: {formatCurrency(item.revenue)}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Top Performing Content */}
            <Card>
              <CardHeader>
                <CardTitle>Top Performing Content</CardTitle>
                <CardDescription>
                  Your best performing campaigns and content across all channels
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {[
                    {
                      content: "Diwali Special Offer Campaign",
                      channel: "WhatsApp",
                      language: "hi",
                      reach: 15400,
                      engagement: "8.1%",
                      leads: 67,
                    },
                    {
                      content: "Local Business Spotlight",
                      channel: "Facebook",
                      language: "en",
                      reach: 12800,
                      engagement: "6.9%",
                      leads: 34,
                    },
                    {
                      content: "Regional Product Launch",
                      channel: "Google Ads",
                      language: "te",
                      reach: 8900,
                      engagement: "6.4%",
                      leads: 28,
                    },
                    {
                      content: "Festival Greetings Series",
                      channel: "Instagram",
                      language: "gu",
                      reach: 5600,
                      engagement: "9.2%",
                      leads: 18,
                    },
                  ].map((item, index) => (
                    <div
                      key={index}
                      className="flex items-center justify-between p-3 border rounded-lg"
                    >
                      <div className="flex items-center space-x-4">
                        <div className="text-center">
                          <div className="text-lg font-bold">#{index + 1}</div>
                        </div>
                        <div>
                          <div className="font-medium">{item.content}</div>
                          <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                            <Badge variant="outline">{item.channel}</Badge>
                            <Badge variant="outline">
                              {item.language.toUpperCase()}
                            </Badge>
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                        <span>Reach: {formatNumber(item.reach)}</span>
                        <span>Engagement: {item.engagement}</span>
                        <span>Leads: {item.leads}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="channels" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Channel Performance Comparison</CardTitle>
                <CardDescription>
                  Compare performance across all marketing channels
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Channel</TableHead>
                      <TableHead>Reach</TableHead>
                      <TableHead>Engagement</TableHead>
                      <TableHead>Leads</TableHead>
                      <TableHead>Cost</TableHead>
                      <TableHead>ROI</TableHead>
                      <TableHead>Trend</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {mockChannelPerformance.map((channel, index) => {
                      const Icon = channel.icon;
                      return (
                        <TableRow key={index}>
                          <TableCell>
                            <div className="flex items-center space-x-2">
                              <Icon className="h-4 w-4" />
                              <span className="font-medium">
                                {channel.channel}
                              </span>
                            </div>
                          </TableCell>
                          <TableCell>{formatNumber(channel.reach)}</TableCell>
                          <TableCell>
                            {formatNumber(channel.engagement)}
                          </TableCell>
                          <TableCell>{channel.leads}</TableCell>
                          <TableCell>{formatCurrency(channel.cost)}</TableCell>
                          <TableCell>
                            <span
                              className={
                                channel.roi >= 3
                                  ? "text-green-600 font-medium"
                                  : "text-orange-600"
                              }
                            >
                              {channel.roi}x
                            </span>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center space-x-1">
                              {getTrendIcon(channel.trend)}
                              <span className={getTrendColor(channel.trend)}>
                                {channel.trend}
                              </span>
                            </div>
                          </TableCell>
                          <TableCell>
                            <Button size="sm" variant="outline">
                              Optimize
                            </Button>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>

            {/* Channel Deep Dive */}
            <div className="grid gap-6 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle>WhatsApp Performance</CardTitle>
                  <CardDescription>
                    Detailed WhatsApp marketing metrics
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Message Delivery Rate</span>
                    <span className="font-medium">97.2%</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Read Rate</span>
                    <span className="font-medium">84.6%</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Response Rate</span>
                    <span className="font-medium">12.8%</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Average Response Time</span>
                    <span className="font-medium">2.3 hours</span>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Social Media Insights</CardTitle>
                  <CardDescription>
                    Facebook & Instagram performance metrics
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Post Reach Rate</span>
                    <span className="font-medium">23.4%</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Story Completion Rate</span>
                    <span className="font-medium">78.9%</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Share Rate</span>
                    <span className="font-medium">4.2%</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Follower Growth</span>
                    <span className="font-medium text-green-600">
                      +156 this month
                    </span>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="languages" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Language Performance Analysis</CardTitle>
                <CardDescription>
                  Compare marketing performance across different regional
                  languages
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Language</TableHead>
                      <TableHead>Reach</TableHead>
                      <TableHead>Engagement</TableHead>
                      <TableHead>Conversion Rate</TableHead>
                      <TableHead>Revenue</TableHead>
                      <TableHead>Campaigns</TableHead>
                      <TableHead>CPL</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {mockLanguagePerformance.map((lang, index) => (
                      <TableRow key={index}>
                        <TableCell>
                          <div className="flex items-center space-x-2">
                            <Languages className="h-4 w-4" />
                            <div>
                              <div className="font-medium">
                                {lang.nativeName}
                              </div>
                              <div className="text-xs text-muted-foreground">
                                {lang.language.toUpperCase()}
                              </div>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>{formatNumber(lang.reach)}</TableCell>
                        <TableCell>{formatNumber(lang.engagement)}</TableCell>
                        <TableCell>
                          <div className="flex items-center space-x-2">
                            <div className="w-16 h-2 bg-gray-200 rounded-full">
                              <div
                                className="h-full bg-blue-500 rounded-full"
                                style={{
                                  width: `${lang.conversionRate * 20}%`,
                                }}
                              />
                            </div>
                            <span className="text-sm">
                              {lang.conversionRate}%
                            </span>
                          </div>
                        </TableCell>
                        <TableCell>{formatCurrency(lang.revenue)}</TableCell>
                        <TableCell>{lang.campaigns}</TableCell>
                        <TableCell>
                          ₹
                          {Math.round(
                            lang.revenue / (lang.conversionRate * 10),
                          )}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>

            {/* Language Insights */}
            <div className="grid gap-6 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle>Regional Preferences</CardTitle>
                  <CardDescription>
                    Content preferences by language and region
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {[
                      {
                        language: "हिंदी",
                        preference: "Festival campaigns",
                        performance: "+35%",
                      },
                      {
                        language: "English",
                        preference: "Professional content",
                        performance: "+28%",
                      },
                      {
                        language: "తెలుగు",
                        preference: "Local business stories",
                        performance: "+42%",
                      },
                      {
                        language: "ગુજરાતી",
                        preference: "Business offers",
                        performance: "+31%",
                      },
                    ].map((item, index) => (
                      <div
                        key={index}
                        className="flex items-center justify-between p-3 bg-gray-50 rounded-lg"
                      >
                        <div>
                          <div className="font-medium">{item.language}</div>
                          <div className="text-sm text-muted-foreground">
                            {item.preference}
                          </div>
                        </div>
                        <div className="text-green-600 font-medium">
                          {item.performance}
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Optimal Posting Times</CardTitle>
                  <CardDescription>
                    Best times to post for each language audience
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {[
                      {
                        language: "हिंदी",
                        time: "7:00 PM - 9:00 PM",
                        day: "Weekdays",
                      },
                      {
                        language: "English",
                        time: "8:00 AM - 10:00 AM",
                        day: "Monday-Friday",
                      },
                      {
                        language: "తెలుగు",
                        time: "6:00 PM - 8:00 PM",
                        day: "Weekends",
                      },
                      {
                        language: "ગુજરાતી",
                        time: "12:00 PM - 2:00 PM",
                        day: "All days",
                      },
                    ].map((item, index) => (
                      <div
                        key={index}
                        className="flex items-center justify-between"
                      >
                        <div>
                          <div className="font-medium">{item.language}</div>
                          <div className="text-sm text-muted-foreground">
                            {item.day}
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="font-medium text-sm">{item.time}</div>
                          <div className="text-xs text-muted-foreground">
                            Peak hours
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="campaigns" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Campaign Performance</CardTitle>
                <CardDescription>
                  Track individual campaign metrics and ROI
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Campaign</TableHead>
                      <TableHead>Channel</TableHead>
                      <TableHead>Language</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Reach</TableHead>
                      <TableHead>Engagement</TableHead>
                      <TableHead>Leads</TableHead>
                      <TableHead>ROI</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {mockCampaigns.map((campaign) => (
                      <TableRow key={campaign.id}>
                        <TableCell>
                          <div>
                            <div className="font-medium">{campaign.name}</div>
                            <div className="text-xs text-muted-foreground">
                              Started {campaign.startDate}
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline">{campaign.channel}</Badge>
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline">
                            {campaign.language.toUpperCase()}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Badge
                            variant={
                              campaign.status === "active"
                                ? "default"
                                : campaign.status === "completed"
                                  ? "secondary"
                                  : "outline"
                            }
                          >
                            {campaign.status}
                          </Badge>
                        </TableCell>
                        <TableCell>{formatNumber(campaign.reach)}</TableCell>
                        <TableCell>
                          {formatNumber(campaign.engagement)}
                        </TableCell>
                        <TableCell>{campaign.leads}</TableCell>
                        <TableCell>
                          <span className="font-medium text-green-600">
                            {(campaign.revenue / campaign.cost).toFixed(1)}x
                          </span>
                        </TableCell>
                        <TableCell>
                          <div className="flex space-x-1">
                            <Button size="sm" variant="outline">
                              View
                            </Button>
                            {campaign.status === "active" && (
                              <Button size="sm" variant="outline">
                                Edit
                              </Button>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="insights" className="space-y-6">
            <div className="grid gap-6 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle>AI Insights & Recommendations</CardTitle>
                  <CardDescription>
                    Data-driven suggestions to improve your marketing
                    performance
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {[
                    {
                      type: "optimization",
                      title: "Increase Hindi Content",
                      description:
                        "Hindi content shows 35% higher engagement. Consider increasing Hindi campaigns.",
                      impact: "High",
                      action: "Create Campaign",
                    },
                    {
                      type: "timing",
                      title: "Optimize Posting Schedule",
                      description:
                        "Posts between 7-9 PM get 42% more engagement for your audience.",
                      impact: "Medium",
                      action: "Update Schedule",
                    },
                    {
                      type: "budget",
                      title: "Reallocate Budget",
                      description:
                        "WhatsApp shows highest ROI. Consider shifting 20% budget from other channels.",
                      impact: "High",
                      action: "Adjust Budget",
                    },
                  ].map((insight, index) => (
                    <div key={index} className="p-4 border rounded-lg">
                      <div className="flex items-start justify-between mb-2">
                        <div className="flex items-center space-x-2">
                          <Award className="h-4 w-4 text-blue-600" />
                          <span className="font-medium">{insight.title}</span>
                        </div>
                        <Badge
                          variant={
                            insight.impact === "High" ? "default" : "secondary"
                          }
                        >
                          {insight.impact} Impact
                        </Badge>
                      </div>
                      <p className="text-sm text-muted-foreground mb-3">
                        {insight.description}
                      </p>
                      <Button size="sm" variant="outline">
                        {insight.action}
                      </Button>
                    </div>
                  ))}
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Growth Opportunities</CardTitle>
                  <CardDescription>
                    Identify new markets and optimization areas
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {[
                    {
                      market: "Tier 3 Cities",
                      opportunity: "Underexplored market with high potential",
                      growth: "+65% potential",
                      languages: ["hi", "te"],
                    },
                    {
                      market: "Instagram Reels",
                      opportunity: "Video content shows 3x higher engagement",
                      growth: "+120% engagement",
                      languages: ["en", "hi"],
                    },
                    {
                      market: "Festival Campaigns",
                      opportunity: "Upcoming festivals show high search volume",
                      growth: "+85% seasonal lift",
                      languages: ["hi", "gu", "te"],
                    },
                  ].map((opportunity, index) => (
                    <div key={index} className="p-4 border rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-medium">
                          {opportunity.market}
                        </span>
                        <span className="text-green-600 font-medium">
                          {opportunity.growth}
                        </span>
                      </div>
                      <p className="text-sm text-muted-foreground mb-2">
                        {opportunity.opportunity}
                      </p>
                      <div className="flex items-center space-x-2">
                        <span className="text-xs text-muted-foreground">
                          Best languages:
                        </span>
                        {opportunity.languages.map((lang) => (
                          <Badge
                            key={lang}
                            variant="outline"
                            className="text-xs"
                          >
                            {lang.toUpperCase()}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </div>

            {/* Competitive Analysis */}
            <Card>
              <CardHeader>
                <CardTitle>Market Position</CardTitle>
                <CardDescription>
                  How you compare to similar businesses in your market
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid gap-6 md:grid-cols-3">
                  <div className="text-center">
                    <div className="text-3xl font-bold text-green-600">
                      Top 15%
                    </div>
                    <div className="text-sm text-muted-foreground">
                      Engagement Rate
                    </div>
                    <div className="text-xs text-muted-foreground">
                      Above industry average
                    </div>
                  </div>
                  <div className="text-center">
                    <div className="text-3xl font-bold text-blue-600">
                      Top 25%
                    </div>
                    <div className="text-sm text-muted-foreground">
                      Conversion Rate
                    </div>
                    <div className="text-xs text-muted-foreground">
                      Good performance
                    </div>
                  </div>
                  <div className="text-center">
                    <div className="text-3xl font-bold text-orange-600">
                      Top 40%
                    </div>
                    <div className="text-sm text-muted-foreground">
                      Market Reach
                    </div>
                    <div className="text-xs text-muted-foreground">
                      Room for growth
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  );
}
